<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<section class="privacy">
	<div class="container">
		<h2 class="text-center"><?= ucwords($title) ?></h2>
		<?= $data['details'] ?>
	</div>
</section>