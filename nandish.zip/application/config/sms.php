<?php defined("BASEPATH") OR exit("No direct script access allowed");
/*creds for https://smartping.live/entity/login : nandish.jewellers@gmail.com pass - PHP6RO6T*/

$config["OTP_TEMPLATE"]= "1707163332645882555";
$config["OTP_SMS"]= "nandish jweller login OTP is{#var#}";

$config["Singup_TEMPLATE"]= "1707163332287865903";
$config["Singup_SMS"]= "Thank you! Thanks for signing up. Welcome to nandish.in";

$config["Confirmation_TEMPLATE"]= "1707163332291188566";
$config["Confirmation_SMS"]= "Thanks for shopping with us! Your order is confirmed and will be shipped shortly. Check your status here www.nandish.in";

$config["ThankYou_TEMPLATE"]= "1707163332304693424";
$config["ThankYou_SMS"]= "Thank u for shopping with www.nandish.in";

// pending
$config["Shipped_TEMPLATE"]= "1707163332300902584";
$config["Shipped_SMS"]= "hi {#var#} your package has now been shipped , view track in www.nandish.in";

$config["AdminConfirm_TEMPLATE"]= "1707163332297448800";
$config["AdminConfirm_SMS"]= "new order {#var#} receive in system in www.nandish.in";
	

/* $config["Confirm_TEMPLATE"]= "1707163332294252963";
$config["Confirm_SMS"]= "Hello {#var1#}, your Jewelery Order {#var2#} has been receive , thank u for shopping with nandish.in"; */

$config["admin_mobile"]= "8000104444";