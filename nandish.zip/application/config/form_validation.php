<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

$config['error_prefix'] = '<span class="messages"><p class="text-danger error">';
$config['error_suffix'] = '</p></span>';