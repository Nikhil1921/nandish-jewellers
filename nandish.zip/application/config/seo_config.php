<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['seo_title'] = APP_NAME;
$config['seo_desc'] = APP_NAME;
$config['seo_imgurl'] = base_url('admin/image/logo.png');