<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Public_model extends MY_Model
{
	
}