<?php if(empty($_GET['payment-id'])) echo "<script>window.open('index.php','_self');</script>";
include_once "paykun.php";
$response = $paykun->getTransactionInfo($_REQUEST['payment-id']);
include('include/header.php') ?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Payment Status</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="about-us section-padding">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5">
                <div class="about-thumb">
                    <img src="<?= base_url() ?>img/about/about.png" alt="about thumb">
                </div>
            </div>
            <div class="col-lg-7">
                <div class="about-content">
                    <div class="section-title text-center">
                        <h2 class="title">Payment Status</h2>
                    </div>
                </div>
                <?php if(is_array($response) && !empty($response)): ?>
                <?php 
                if($response['status'] && $response['data']['transaction']['status'] == "Success"):
                    $payment_id = $_REQUEST['payment-id'];
                    $sql_us = "SELECT * FROM user where u_id = '$id'";
                    $run_us=mysqli_query($connect,$sql_us);
                    $user = mysqli_fetch_assoc($run_us);
                    $post = $response['data']['transaction'];
                    $sql = "SELECT o_payment FROM orders WHERE o_payment = '$payment_id'";
                    $run = mysqli_query($connect,$sql);
                    if (!mysqli_fetch_assoc($run)):
                        $sql = "SELECT * FROM cart c
                        join product p on p.p_id = c.ca_pro_id
                        join category ca on ca.c_id = p.p_cat
                        where c.ca_u_id = '$id'";
                        $run = mysqli_query($connect,$sql);
                        $cart = [];
                        $date = date('d-m-Y');
                        $time = date('h:i:s A');
                        $address = $user['u_address'];
                        $city = $user['u_city'];
                        $state = $user['u_state'];
                        $country = "India";
                        $pin = $user['u_postcode'];
                        $pancard = $user['u_pancard'];
                        $note = $post['custom_field_1'];
                        while ($data = mysqli_fetch_assoc($run)):
                            $cart[] = $data;
                        endwhile;
                        $total = array_sum(array_map(function($c) {
                        $makec = $c['p_l_char'];
                        if (isset($_SESSION['coupen_id'])):
                        $makec = $makec * (100 - $_SESSION['discount']) / 100;
                        endif;
                        return round(($c[$c['p_carat']] * $c['p_gram'] + $c['p_other'] + $makec) * $c['ca_qty'] * 1.03);
                        }, $cart));
                        foreach ($cart as $k => $v):
                        $details[$k]['prod_id'] = $v['ca_pro_id'];
                        $details[$k]['qty'] = $v['ca_qty'];
                        $makec = $v['p_l_char'];
                        if (isset($_SESSION['coupen_id'])):
                        $makec = $makec * (100 - $_SESSION['discount']) / 100;
                        endif;
                        $makec = round($makec);
                        $details[$k]['price'] = round($v[$v['p_carat']] * $v['p_gram']);
                        $details[$k]['size'] = ($v['ca_size']) ? $v['ca_size'] : 'NA';
                        $details[$k]['shipping'] = round($v['p_shipping'] * 1.03);
                        $details[$k]['other'] = $v['p_other'];
                        $details[$k]['making'] = $makec;
                        $details[$k]['total'] = round(($v[$v['p_carat']] * $v['p_gram'] + $v['p_other'] + $makec) * $v['ca_qty'] * 1.03);
                        $details[$k]['pre'] = $v['p_pre'];
                        $total += round($v['p_shipping'] * 1.03);
                        endforeach;
                        $o_details = json_encode($details);
                        $invoice = 'NAD'.rand(1000,9999);
                        $sql_add = "INSERT INTO `orders`(`o_details`, `o_u_id`, `o_total`, `o_date`, `o_time`, `o_address`, `o_city`, `o_state`, `o_country`, `o_pin`, `o_note`, `o_invoice`, `o_payment`, `o_pancard`) VALUES ('$o_details','$id','$total','$date','$time','$address','$city','$state','$country','$pin','$note','$invoice','$payment_id','$pancard')";
                        if(mysqli_query($connect, $sql_add)):
                        $order_id = mysqli_insert_id($connect);
                        $sql_del = "DELETE FROM cart where ca_u_id = '$id'";
                        mysqli_query($connect, $sql_del);
                        if (isset($_SESSION['coupen_id'])):
                            $coupen = $_SESSION['coupen_id'];
                            $sql_coupen = "UPDATE `code` SET `co_status`=1, `co_order`='$order_id' WHERE co_id = '$coupen'";
                            mysqli_query($connect,$sql_coupen);
                            unset($_SESSION['coupen_id']);
                            unset($_SESSION['discount']);
                        endif;
                        foreach ($cart as $qty):
                            if (!$qty['p_pre']):
                                $p_id = $qty['p_id'];
                                $new = ($qty['p_qty_avail'] - $qty['ca_qty']);
                                $sql_qty = "UPDATE `product` SET `p_qty_avail`='$new' WHERE p_id = '$p_id'";
                                mysqli_query($connect, $sql_qty);
                            endif;
                        endforeach;
                    endif;
                endif;
                ?>
                <h5 class="about-sub-title">
                Payment success
                </h5>
                <p>Your order is successful. Save this Transaction ID for future use.<br>
                <?= $_REQUEST['payment-id'] ?>  </p>
                <?php elseif ($response['status'] && $response['data']['transaction']['status'] == "Failed"): ?>
                <h5 class="about-sub-title">
                Error in payment
                </h5>
                <p>Save this Transaction ID for future use if amount debited from your bank.<br>
                <?= $_REQUEST['payment-id'] ?>  </p>
                <?php else: ?>
                <script>window.open("index.php", "_self");</script>
                <?php endif ?>
                <?php endif ?>
            </div>
        </div>
    </div>
</section>
<?php include('include/footer.php') ?>