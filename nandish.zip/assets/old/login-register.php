<?php
	include('include/header.php');
    if (isset($_SESSION['id']))
        echo '<script>window.open("my-account.php","_self");</script>';

    if (isset($_POST['submit']))
    {
        $u_f_name = $_POST['fname'];
        $u_l_name = $_POST['lname'];
        $u_m_name = $_POST['mname'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'];
        $address = "NA";
        $password = $_POST['password'];
        $re_password = $_POST['re_password'];

        if ($password == $re_password)
        {
            $pass = md5($password);
            $sql = "INSERT INTO `user`(`u_f_name`, `u_l_name`, `u_m_name`, `u_mobile`, `u_password`, `u_email`, `u_address`) VALUES ('$u_f_name','$u_l_name','$u_m_name','$mobile','$pass','$email','$address')";
            $run = mysqli_query($connect,$sql);
            if($run == true)
            {
                echo "<script>alert('Register successfully');window.open('login-register.php','_self');</script>";
            }else{
                echo "<script>alert('Register not successfull');window.open('login-register.php','_self');</script>";
            }
        }
        else
        {
           echo "<script>alert('Password Are Not Match');window.open('login-register.php','_self');</script>";
        }
    }

    if (isset($_POST['submit_login']))
    {
        $mobile = $_POST['mobile'];
        $password = $_POST['password'];

        $pass = md5($password);
        $sql = "SELECT * FROM user where u_mobile = '$mobile' AND u_password = '$pass'";
        $run = mysqli_query($connect,$sql);
        if($data = mysqli_fetch_assoc($run))
        {
            $_SESSION['id'] = $data['u_id'];
            echo "<script>alert('Login successfully');window.open('index.php','_self');</script>";
        }
        else
        {
           echo "<script>alert('Mobile or Password not correct');window.open('login-register.php','_self');</script>";
        }
    }
?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">login-Register</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="login-register-wrapper section-padding">
    <div class="container">
        <div class="member-area-from-wrap">
            <div class="row">
                <!-- Login Content Start -->
                <div class="col-lg-6">
                    <div class="login-reg-form-wrap">
                        <h5>Sign In</h5>
                        <form method="post">
                            <div class="single-input-item">
                                <input type="text" placeholder="Enter Mobile" required name="mobile" maxlength="10" />
                            </div>
                            <div class="single-input-item">
                                <input type="password" placeholder="Enter your Password" required name="password" />
                            </div>
                            <!-- <div class="single-input-item">
                                <div
                                    class="login-reg-form-meta d-flex align-items-center justify-content-between">
                                    <div class="remember-meta">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="rememberMe">
                                            <label class="custom-control-label" for="rememberMe">Remember
                                            Me</label>
                                        </div>
                                    </div>
                                    <a href="#" class="forget-pwd"  data-toggle="modal" data-target="#forgotpassword">Forget Password?</a>
                                </div>
                            </div> -->
                            <div class="single-input-item">
                                <button class="btn btn-sqr" name="submit_login">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Login Content End -->
                <!-- Register Content Start -->
                <div class="col-lg-6">
                    <div class="login-reg-form-wrap sign-up-form">
                        <h5>Singup Form</h5>
                        <form method="post">
                            <div class="row ">
                                <div class="col-12 single-input-item">
                                    <input type="text" placeholder="First Name" required name="fname" />
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-12 single-input-item">
                                    <input type="text" placeholder="Middle Name" required name="mname" />
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-12 single-input-item">
                                    <input type="text" placeholder="Last Name" required name="lname" />
                                </div>
                            </div>
                            <div class="row ">
                                <div class="col-12 single-input-item">
                                    <input type="text" placeholder="Mobile Number" required name="mobile" maxlength="10" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 single-input-item">
                                    <input type="email" placeholder="Enter your Email" required name="email" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="single-input-item">
                                        <input type="password" placeholder="Enter your Password" required name="password" />
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="single-input-item">
                                        <input type="password" placeholder="Repeat your Password" required name="re_password" />
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="single-input-item">
                                <div class="login-reg-form-meta">
                                    <div class="remember-meta">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input"
                                            id="subnewsletter" required="">
                                            <label class="custom-control-label" for="subnewsletter">Subscribe
                                            Our Newsletter</label>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <div class="single-input-item">
                                <button class="btn btn-sqr" name="submit">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Register Content End -->
            </div>
        </div>
    </div>
</div>
<?php
	include('include/footer.php')
?>