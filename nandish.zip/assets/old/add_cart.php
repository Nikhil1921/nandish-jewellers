<?php
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ):
	include("admin/layout/connect.php");
	session_start();
	if (!isset($_SESSION['id'])) {
		$return = ['error' => true, 'message' => "Login first"];
		echo json_encode($return); die();
	}
	$u_id = $_SESSION['id'];
	$qty = ($_POST['qty']) ? $_POST['qty'] : 1;
	$p_id = $_POST['p_id'];
	$page = (isset($_POST['page'])) ? $_POST['page'] : '';
	$pro_sql = "SELECT p_qty_avail, p_name, p_size, p_pre FROM product p WHERE p_id = '$p_id'";
	$pro_run = mysqli_query($connect, $pro_sql);
	$pro_data = (object) mysqli_fetch_assoc($pro_run);
	
	if ($pro_data):
		if ($pro_data->p_qty_avail >= $qty):
			$ca_size = (isset($_POST['ca_size']) && $_POST['ca_size']) ? $_POST['ca_size'] : $pro_data->p_size;
			$ca_pre_order = $pro_data->p_pre;
			// $ca_pre_order = (isset($_POST['ca_size']) && $_POST['ca_size']) ? 1 : 0;
			$sql = "SELECT * FROM cart where ca_u_id = '$u_id' AND ca_pro_id = '$p_id'";
			$run = mysqli_query($connect, $sql);
			if(0 < mysqli_num_rows($run)):
				$return = ['error' => false, 'message' => "This Jewellery Is Alredy In Cart."];
			else:
				$cart = "INSERT INTO cart (ca_u_id, ca_pro_id, ca_qty, ca_size, ca_pre_order) VALUES ('$u_id','$p_id','$qty','$ca_size','$ca_pre_order')";
				if (mysqli_query($connect,$cart))
					$return = ['error' => false, 'message' => "Add to cart successful."];
				else
					$return = ['error' => true, 'message' => "Error while adding to cart."];
			endif;
		else:
			$return = ['error' => true, 'message' => "Only $pro_data->p_qty_avail $pro_data->p_name available."];
		endif;
	else:
		$return = ['error' => true, 'message' => "Jewellery not available."];
	endif;
	echo json_encode($return); die();
else:
	echo '<script>window.open("index.php","_self");</script>';
endif;