<?php
	include("admin/layout/connect.php");
	session_start();
	if (!isset($_SESSION['id'])) {
	    echo '<script>alert("Please login first.");window.open("login-register.php","_self");</script>';
	}
	$wish = $_GET['w_id'];

	$wishes = "DELETE FROM wish where w_id = '$wish'";
	if(mysqli_query($connect,$wishes))
	{
		echo "<script>alert('Delete Wishlist Successfully');window.open('wishlist.php','_self');</script>";
	}
	else
	{
		echo "<script>alert('Delete Wishlist Not successfully');window.open('wishlist.php','_self');</script>";
	}
?>