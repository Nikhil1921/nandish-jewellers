<?php include('include/header.php');
if (!isset($_SESSION['id'])) {
echo '<script>alert("Please login first.");window.open("login-register.php","_self");</script>';
}
?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">cart</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="cart-main-wrapper section-padding">
    <div class="container">
        <div class="section-bg-color">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Cart Table Area -->
                    <div class="cart-table table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="pro-thumbnail">Thumbnail</th>
                                    <th class="pro-title">Jewellery</th>
                                    <th class="pro-quantity">Quantity</th>
                                    <th class="pro-subtotal">Price</th>
                                    <th class="pro-remove">Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM cart c
                                join product p on p.p_id = c.ca_pro_id
                                join category ca on ca.c_id = p.p_cat
                                where c.ca_u_id = '$id'";
                                $run = mysqli_query($connect,$sql);
                                if (mysqli_num_rows($run) > 0): $total = 0;
                                while ($cart = mysqli_fetch_assoc($run)):
                                $imge = explode(",", $cart['p_image']);
                                $total += round(($cart[$cart['p_carat']] * $cart['p_gram'] + $cart['p_other'] + $cart['p_l_char']) * $cart['ca_qty'] * 1.03);
                                ?>
                                <tr>
                                    <td class="pro-thumbnail">
                                        <img class="img-fluid"
                                        src="<?= base_url() ?>admin/image/product/<?= $imge[0] ?>" alt="Jewellery" />
                                    </td>
                                    <td class="pro-title"><?= $cart['p_name'] ?></td>
                                    <td class="pro-quantity">
                                        <div class="pro-qty">
                                            <input type="text" readonly="" data-id="<?= $cart['ca_id'] ?>" value="<?= $cart['ca_qty'] ?>" />
                                        </div>
                                    </td>
                                    <td class="pro-subtotal"><span><i class="fa fa-inr" aria-hidden="true"></i> <?= round(($cart[$cart['p_carat']] * $cart['p_gram'] + $cart['p_other'] + $cart['p_l_char']) * $cart['ca_qty'] * 1.03) ?></span></td>
                                    <td class="pro-remove">
                                        <a class="delete-cart" data-id="<?= $cart['ca_id'] ?>"><i class="fa fa-trash-o"></i></a></td>
                                    </tr>
                                    <?php endwhile;
                                    else: ?>
                                    <tr>
                                        <td class="pro-title" colspan="5">
                                            Your Bag is Empty.
                                        </td>
                                    </tr>
                                    <?php endif ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php if (mysqli_num_rows($run) > 0): ?>
                <div class="row">
                    <div class="col-lg-5 ml-auto">
                        <!-- Cart Calculation Area -->
                        <div class="cart-calculator-wrapper">
                            <div class="cart-calculate-items">
                                <h6>Cart Totals</h6>
                                <div class="table-responsive">
                                    <table class="table">
                                        <!-- <tr>
                                            <td>Sub Total</td>
                                            <td><i class="fa fa-inr" aria-hidden="true"></i>
                                            <?= $total ?></td>
                                        </tr> -->
                                        <!-- <tr>
                                            <td>GST (3%)</td>
                                            <td><i class="fa fa-inr" aria-hidden="true"></i>
                                                <?php
                                                $gst = ($total * 3) / 100;
                                                echo $gst;
                                                ?>
                                            </td>
                                        </tr> -->
                                        <tr class="total">
                                            <td>Total</td>
                                            <td class="total-amount"><i class="fa fa-inr" aria-hidden="true"></i><?php echo $total ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <a href="<?= base_url('checkout.php') ?>" class="btn btn-sqr d-block">Proceed Checkout</a>
                        </div>
                    </div>
                </div>
                <?php endif ?>
            </div>
        </div>
    </div>
    <?php include('include/footer.php') ?>
    <script>

    $(".qtybtn").click(function(){
        var $button = $(this);
        var oldValue = $button.parent().find('input').val();
        if ($button.hasClass('inc'))
            var qty = parseInt(oldValue) + 1;
        else
            if (oldValue > 1)
                var qty = parseInt(oldValue) - 1;
            else
                return false;
        
        let cart_id = $(this).siblings('input').data('id');
        $.ajax({
            type: 'POST',
            url: "update_cart.php",
            data: {qty:qty, cart_id:cart_id},
            dataType: "json",
            success: function(result) {
                alert(result.message);
                location.reload();
            }
        });
    });
    $(".delete-cart").click(function(e){
    e.preventDefault();
    let cart_id = $(this).data('id');
    $.ajax({
    type: 'POST',
    url: "cart_delete.php",
    data: {cart_id:cart_id},
    dataType: "json",
    success: function(result) {
    alert(result.message);
    if (!result.error) { location.reload() }
    }
    });
    });
    </script>