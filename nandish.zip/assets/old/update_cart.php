<?php

if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ):
    include("admin/layout/connect.php");
    session_start();
    if (!isset($_SESSION['id'])) {
        $return = ['error' => true, 'message' => "Login first"];
        echo json_encode($return); die();
    }
    $post = (object) $_POST;
    $pro_sql = "SELECT ca_id, ca_pro_id FROM `cart` where ca_id = '$post->cart_id'";
    $pro_run = mysqli_query($connect,$pro_sql);
    $pro_data = mysqli_fetch_assoc($pro_run);
    if ($pro_data):
        $qty = ($post->qty) ? $post->qty : 1;
        $p_id = $pro_data['ca_pro_id'];
        $pro_sql = "SELECT p_qty_avail, p_name FROM product p WHERE p_id = '$p_id'";
        $pro_run = mysqli_query($connect, $pro_sql);
        $pro_data = (object) mysqli_fetch_assoc($pro_run);

        if ($pro_data):
            if ($pro_data->p_qty_avail >= $qty):
                $sql = "UPDATE cart SET ca_qty = '$qty' WHERE ca_id = '$post->cart_id'";
                if (mysqli_query($connect, $sql))
                    $return = ['error' => false, 'message' => "Cart updated."];
                else
                    $return = ['error' => true, 'message' => "Cart not updated."];
            else:
                $return = ['error' => true, 'message' => "Only $pro_data->p_qty_avail $pro_data->p_name available."];
            endif;
        else:
            $return = ['error' => true, 'message' => "Jewellery not available."];
        endif;
    else:
        $return = ['error' => true, 'message' => "Jewellery not in cart list."];
    endif;
    echo json_encode($return); die();
else:
    echo '<script>window.open("index.php","_self");</script>';
endif;