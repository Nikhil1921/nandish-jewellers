<?php
    include('include/header.php');
    if (!isset($_SESSION['id'])) {
        echo '<script>alert("Please login first.");window.open("login-register.php","_self");</script>';
    }
    $sql_us = "SELECT * FROM user where u_id = '$id'";
    $run_us=mysqli_query($connect,$sql_us);
    $user = mysqli_fetch_assoc($run_us);
    $sql = "SELECT * FROM cart c
    join product p on p.p_id = c.ca_pro_id
    join category ca on ca.c_id = p.p_cat
    where c.ca_u_id = '$id'";
    $run = mysqli_query($connect,$sql);
    $cart = [];
    $ship = 0;
    while ($data = mysqli_fetch_assoc($run)):
        $cart[] = $data;
        $ship += round($data['p_shipping'] * 1.03);
    endwhile;

    if (!$cart)
        echo "<script>alert('Your cart is empty.');window.open('index.php','_self');</script>";
    $shipping = 0;
    $total = array_sum(array_map(function($c) {
        $makec = $c['p_l_char'];
        if (isset($_SESSION['coupen_id'])):
           $makec = $makec * (100 - $_SESSION['discount']) / 100;
        endif;
        return round(($c[$c['p_carat']] * $c['p_gram'] + $c['p_other'] + $makec) * $c['ca_qty'] * 1.03);
    }, $cart));
    
    if (isset($_POST['coupen_code'])) {
        $coupen = $_POST['coupen_code'];
        $sql1 = "SELECT co_par, co_id FROM code where co_code = '$coupen' AND co_status = 0";
        $run1 = mysqli_query($connect, $sql1);
        if (!$check = mysqli_fetch_assoc($run1)) {
            echo "<script>alert('Invalid coupen code.');window.open('checkout.php','_self');</script>";
        }else{
            $_SESSION['coupen_id'] = $check['co_id'];
            $_SESSION['discount'] = $check['co_par'];
            $_SESSION['coupen_code'] = $_POST['coupen_code'];
            echo "<script>alert('Coupen code applied.');window.open('checkout.php','_self');</script>";
        }
    }

    if (isset($_POST['submit'])):
        $post = $_POST;
        $address = $post['address'];
        $city = $post['city'];
        $state = $post['state'];
        $country = $post['country'];
        $pin = $post['pin'];
        $pancard = (isset($post['pancard'])) ? $post['pancard'] : 'NA';
        $sql_user = "UPDATE `user` SET `u_address` = '$address', `u_city` = '$city', `u_state` = '$state', `u_postcode` = '$pin', `u_pancard` = '$pancard' where `u_id` = '$id'";
        mysqli_query($connect, $sql_user);
        $root = (isset($_SERVER["HTTPS"]) ? "https://" : "http://").$_SERVER["HTTP_HOST"];
        $root .= str_replace(basename($_SERVER["SCRIPT_NAME"]), "", $_SERVER["SCRIPT_NAME"]);
        include_once "paykun.php";
        // Initializing Order
        $paykun->initOrder(rand(10000000000, 99999999999), $user['u_f_name'].' '.$user['u_m_name'].' '.$user['u_l_name'], $total + $ship, $root.'payment.php', $root.'payment.php', 'INR');
        // Add Customer
        $paykun->addCustomer($user['u_f_name'].' '.$user['u_m_name'].' '.$user['u_l_name'], $user['u_email'], $user['u_mobile']);
         
        // Add Shipping address
        $paykun->addShippingAddress('India', $post['state'], $post['city'], $post['pin'], $post['address']);
         
        // Add Billing Address
        $paykun->addBillingAddress('India', $post['state'], $post['city'], $post['pin'], $post['address']);
        $paykun->setCustomFields(array('udf_1' => ($post['note']) ? $post['note'] : 'NA'));
        
        echo $paykun->submit();
        die();
    endif;
?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?= base_url('cart.php') ?>">Cart</a></li>
                            <li class="breadcrumb-item active" aria-current="page">checkout</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="checkout-page-wrapper section-padding">
    <div class="container">
        <?php if ($total > 0 && !isset($_SESSION['coupen_id'])): ?>
        <div class="row">
            <div class="col-12">
                <div class="checkoutaccordion" id="checkOutAccordion">
                    <div class="card">
                        <h6>Have A Gift card?</h6>
                        <div id="couponaccordion" class="collapse show" data-parent="#checkOutAccordion">
                            <div class="card-body">
                                <div class="cart-update-option">
                                    <div class="apply-coupon-wrapper">
                                        <form method="post" class="d-block d-md-flex">
                                            <input type="text" placeholder="Enter Your Gift card" required name="coupen_code" />
                                            <button class="btn btn-sqr">Apply Gift card</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif ?>
        <form method="post">
            <div class="row">
                <!-- Checkout Billing Details -->
                <div class="col-lg-6">
                    <div class="checkout-billing-details-wrap">
                        <h5 class="checkout-title">Billing Details</h5>
                        <div class="billing-form-wrap">
                            <div class="single-input-item">
                                <label for="street-address" class="required mt-20">Street address</label>
                                <input type="text" id="street-address" name="address" placeholder="Street address" required value="<?= $user['u_address'] ?>" />
                            </div>
                            <div class="single-input-item">
                                <label for="town" class="required">Town / City</label>
                                <input type="text" id="town" name="city" placeholder="Town / City" required value="<?= $user['u_city'] ?>" />
                            </div>
                            <div class="single-input-item">
                                <label for="state">State / Divition</label>
                                <input type="text" id="state" name="state" placeholder="State / Divition" value="<?= $user['u_state'] ?>" />
                            </div>
                            <div class="single-input-item">
                                <label for="country" class="required">Country</label>
                                <select name="country" id="country">
                                    <option value="India">India</option>
                                </select>
                            </div>
                            <div class="single-input-item">
                                <label for="postcode" class="required">Postcode / ZIP</label>
                                <input type="text" id="postcode" name="pin" placeholder="Postcode / ZIP" required value="<?= $user['u_postcode'] ?>" />
                            </div>
                            <?php if ($total > 200000): ?>
                            <div class="single-input-item">
                                <label for="pancard" class="required">Pan No.</label>
                                <input type="text" id="pancard" name="pancard" placeholder="Pan No." required maxlength="10" value="<?= $user['u_pancard'] ?>" />
                            </div>
                            <?php endif ?>
                            <div class="single-input-item">
                                <label for="ordernote">Order Note</label>
                                <textarea name="note" id="ordernote" cols="30" rows="3"
                                placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Order Summary Details -->
                <div class="col-lg-6">
                    <div class="order-summary-details">
                        <h5 class="checkout-title">Your Order Summary</h5>
                        <div class="order-summary-content">
                            <!-- Order Summary Table -->
                            <div class="order-summary-table table-responsive text-center">
                                <table class="table table-bordered checkout">
                                    <thead>
                                        <tr>
                                            <th>Jewellery</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($cart as $c): ?>
                                        <tr>
                                            <td>
                                                <?= $c['p_name'] ?> <strong> × <?= $c['ca_qty'] ?> </strong>
                                            </td>
                                            <?php
                                            $makec = $c['p_l_char'];
                                            if (isset($_SESSION['coupen_id'])):
                                                $makec = round($makec * (100 - $_SESSION['discount']) / 100);
                                                $disc = round($makec * (100 - $_SESSION['discount']) / 100);
                                            endif;
                                            $shipping += $c['p_shipping'] ?>
                                            <td class="pro-subtotal"><i class="fa fa-inr" aria-hidden="true"></i> <?= round(($c[$c['p_carat']] * $c['p_gram'] + $c['p_other'] + $makec) * $c['ca_qty'] * 1.03) ?></td>
                                        </tr>
                                        <?php endforeach ?>
                                    </tbody>
                                    <tfoot>
                                    <tr>
                                        <td>Shipping Charge (Including GST)</td>
                                        <td class="pro-subtotal"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $shipping = round($shipping * 1.03) ?></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Total Amount</td>
                                        <td class="pro-subtotal"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $total + $shipping ?></strong>
                                        </td>
                                    </tr>
                                    </tfoot>
                                </table>
                            </div>
                            <div class="order-payment-method">
                                <div class="summary-footer-area">
                                    <button type="submit" name="submit" class="btn btn-sqr">Place Order</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php include('include/footer.php') ?>