<?php
include('include/header.php');
$pro = $_GET['pro'];
if (!$pro): echo '<script>window.open("index.php","_self");</script>'; endif;
$sql = "SELECT * FROM product p 
JOIN category c ON c.c_id = p.p_cat 
JOIN innercategory  i ON i.i_id = p.p_innercat
WHERE p_id = '$pro' AND p_qty_avail > 0";
$run = mysqli_query($connect,$sql);
$data = mysqli_fetch_assoc($run);

if (!$data): echo '<script>window.open("index.php","_self");</script>'; endif;
?>
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page"><a href="<?= base_url('product_list.php?pli='.$data['p_innercat']) ?>"><?= $data['i_name'] ?></a></li>
                            <li class="breadcrumb-item active" aria-current="page">Jewellery details</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="shop-main-wrapper section-padding pb-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 order-1 order-lg-2">
                <div class="product-details-inner">
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="product-large-slider">
                                <?php
                                $imge = explode(",", $data['p_image']);
                                foreach ($imge as $key => $value)
                                {
                                ?>
                                <div class="pro-large-img img-zoom">
                                    <img src="<?= base_url() ?>admin/image/product/<?= $value; ?>"
                                    alt="Jewellery details" />
                                </div>
                                <?php } ?>
                            </div>
                            <div class="pro-nav slick-row-10 slick-arrow-style">
                                <?php
                                $imge = explode(",", $data['p_image']);
                                foreach ($imge as $key => $value)
                                {
                                ?>
                                <div class="pro-nav-thumb">
                                    <img src="<?= base_url() ?>admin/image/product/<?= $value; ?>"
                                    alt="Jewellery details" />
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="col-lg-6 offset-lg-1">
                            <div class="product-details-des">
                                <div class="manufacturer-name">
                                    <a href="javascript:void(0)">Nandish Jewellers</a>
                                </div>
                                <h3 class="product-name"><?= $data['p_name']; ?></h3><span>
                                S.K.U. Code - <?= $data['p_code']; ?></span>
                                <div class="price-box">
                                    <span class="price-regular"><i class="fa fa-inr" aria-hidden="true"></i><?= round(($data[$data['p_carat']] * $data['p_gram'] + $data['p_other'] + $data['p_l_char']) * 1.03) ?></span>
                                </div>
                                <?= $data['p_detail'] ?>
                                <div class="quantity-cart-box d-flex align-items-center">
                                    <h6 class="option-title">qty:</h6>
                                    <div class="quantity">
                                        <div class="pro-qty">
                                            <input type="text" readonly="" name="qty" value="1" id="add-qty-<?= $data['p_id'] ?>" />
                                        </div>
                                    </div>
                                    <div class="action_link">
                                        <?php
                                        $bag = ($data['p_pre']) ? 'Pre Order' : 'Add to Bag';
                                        if(empty($_SESSION['id'])): ?>
                                        <a href="<?= base_url() ?>login-register.php" class="btn btn-cart2"><?= $bag ?></a>
                                        <?php else: ?>
                                        <button class="btn btn-cart" data-p_id="<?= $data['p_id'] ?>" onclick="addToCart(this)"><?= $bag ?></button>
                                        <?php endif ?>
                                    </div>
                                </div>
                                <?php
                                if($data['p_size_type'] != 0)
                                {
                                $size = $data['p_size_type'];
                                $sq = "SELECT * FROM size where s_id = '$size'";
                                $ru = mysqli_query($connect,$sq);
                                $da = mysqli_fetch_assoc($ru);
                                ?>
                                
                                <div class="pro-size" style="display:inline-block;">
                                    <div class="row mb-2">
                                        <div class="col-md-4 col-4 align-self-center pr-0">
                                            <span ><b> Size : </b></span>
                                        
                                            <?php $size = explode(',', $data['p_size']) ?>
                                        
                                            <span><b>(<?= $da['s_name']; ?>) </b></span>
                                        </div>
                                        <div class="col-md-5 col-6">
                                            
                                                
                                                    <input  class="text-center" style="width: 100%;
    height: 40px;
    border: 1px solid #ddd;
    padding: 0 15px;
    border-radius: 40px;" type="text"  name="ca_size" value="<?= reset($size) ?>" id="ca_size" />
                                                
                                                
                                            
                                            
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <?php array_shift($size); ?>
                                        <?php if ($size): ?>
                                        <div class="col-md-6 col-6 align-self-center pr-0">
                                            <p>OR Select size here :</p>
                                        </div>
                                        <div class="col-md-5 col-6 pl-0">
                                            <select class="nice-select" id="ca_size_id" style="width:100%!important;">
                                                <option value="">Select size</option>
                                                <?php
                                                foreach ($size as $si): ?>
                                                <option value="<?= $si ?>"><?= $si ?></option>
                                                <?php endforeach ?>
                                            </select>
                                        </div>
                                        <?php endif ?>
                                    </div>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="product-details-reviews section-padding pb-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="product-review-info">
                                <ul class="nav review-tab">
                                    <li>
                                        <a class="active" data-toggle="tab" href="#tab_one">Details</a>
                                    </li>
                                    <li>
                                        <a data-toggle="tab" href="#tab_two">Invoice</a>
                                    </li>
                                    <li>
                                        <a data-toggle="tab" href="#tab_three">Notes</a>
                                    </li>
                                    
                                </ul>
                                <div class="tab-content reviews-tab">
                                    <div class="tab-pane fade show active" id="tab_one">
                                        <div class="tab-one table Bill-Details">
                                            <?= $data['p_sub_detail'] ?>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade table Bill-Details" id="tab_two">
                                        <table class="table table-bordered Bill-Details">
                                            <tbody>
                                                <tr>
                                                    <td>Gross Weight (Grams)</td>
                                                    <td><?= $data['p_g_wei'] ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Loss Weight (Grams)</td>
                                                    <td><?= $data['p_l_wei'] ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Net Weight (Grams)</td>
                                                    <td><?= $data['p_gram'] ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Rate (Per Grams)</td>
                                                    <td><?= round($data[$data['p_carat']]) ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Making Charge (Per Grams)</td>
                                                    <td><?= ($data['p_make_gram']) ? round($data['p_make_gram']) : 'NA' ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Other Charge</td>
                                                    <td><?= ($data['p_other']) ? round($data['p_other']) : 'NA' ?></td>
                                                </tr>
                                                <tr>
                                                    <td><?= $data['c_name'] ?> Price</td>
                                                    <td><?= round($data['p_gram'] * $data[$data['p_carat']]) ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Total Making Charge</td>
                                                    <td><?= round($data['p_l_char']) ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Taxable Value</td>
                                                    <td><?= round($data[$data['p_carat']] * $data['p_gram'] + $data['p_other'] + $data['p_l_char']) ?></td>
                                                </tr>
                                                <tr>
                                                    <td>G.S.T  (C.S) & (I) 3%</td>
                                                    <td><?= round(($data[$data['p_carat']] * $data['p_gram'] + $data['p_other'] + $data['p_l_char']) * 0.03) ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Total Amount</td>
                                                    <td><?= round(($data[$data['p_carat']] * $data['p_gram'] + $data['p_other'] + $data['p_l_char']) * 1.03) ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="tab-pane fade" id="tab_three">
                                        <?= $data['p_notes'] ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="related-products section-padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="section-title text-center">
                    <h2 class="title">Related Jewellery</h2>
                    <p class="sub-title text-capitalize">Here are some more Jewellery </p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="related-product-carousel slick-row-10 slick-arrow-style">
                    <?php
                    $inn = $data['p_innercat'];
                    $sql1 = "SELECT * FROM product p
                    join category c on c.c_id = p.p_cat
                    join innercategory i on p.p_innercat = i.i_id
                    where p_innercat = '$inn' AND p_qty_avail > 0 AND p_id != '$pro' LIMIT 15";
                    $run1 = mysqli_query($connect,$sql1);
                    while($data1 = mysqli_fetch_assoc($run1))
                    {
                    ?>
                    <div class="product-item">
                        <figure class="product-thumb">
                            <?php $imge = explode(",", $data1['p_image']); ?>
                            <a href="<?= base_url($data1['p_id'].'/'.urlencode($data1['p_name'])) ?>">
                                <img class="pri-img" src="<?= base_url() ?>admin/image/product/<?= reset($imge) ?>" alt="Jewellery">
                            </a>
                            <div class="button-group">
                                <a href="javascript:void(0)" onclick="addWishlist(this)" data-toggle="tooltip" data-placement="left" title="Add to wishlist" data-p_id="<?= $data1['p_id'] ?>"><i><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                    viewBox="0 0 455 455"  xml:space="preserve">
                                    <path d="M326.632,10.346c-38.733,0-74.991,17.537-99.132,46.92c-24.141-29.383-60.399-46.92-99.132-46.92
                                        C57.586,10.346,0,67.931,0,138.714c0,55.426,33.049,119.535,98.23,190.546c50.162,54.649,104.729,96.96,120.257,108.626l9.01,6.769
                                        l9.009-6.768c15.53-11.667,70.099-53.979,120.26-108.625C421.95,258.251,455,194.141,455,138.714
                                        C455,67.931,397.414,10.346,326.632,10.346z"/>
                                    </svg></i></a>
                                    <a href="javascript:void(0)" onclick="showProd(<?= $data1['p_id'] ?>)"><span data-toggle="tooltip" data-placement="left" title="Quick View"><i class="pe-7s-search"></i></span>
                                </a>
                            </div>
                            <div class="cart-hover">
                                <button class="btn btn-cart" data-p_id="<?= $data1['p_id'] ?>" onclick="addToCart(this)"><svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" class="bag1">
                                             <path d="M443.209,442.24l-27.296-299.68c-0.736-8.256-7.648-14.56-15.936-14.56h-48V96c0-25.728-9.984-49.856-28.064-67.936
                                                C306.121,10.24,281.353,0,255.977,0c-52.928,0-96,43.072-96,96v32h-48c-8.288,0-15.2,6.304-15.936,14.56L68.809,442.208
                                                c-1.632,17.888,4.384,35.712,16.48,48.96S114.601,512,132.553,512h246.88c17.92,0,35.136-7.584,47.232-20.8
                                                C438.793,477.952,444.777,460.096,443.209,442.24z M319.977,128h-128V96c0-35.296,28.704-64,64-64
                                                c16.96,0,33.472,6.784,45.312,18.656C313.353,62.72,319.977,78.816,319.977,96V128z"></path>
                                          </svg></button>
                            </div>
                        </figure>
                        <div class="product-caption text-center">
                            <div class="product-identity">
                                <p class="manufacturer-name"><a href="<?= base_url($data1['p_id'].'/'.urlencode($data1['p_name'])) ?>"><?= $data1['i_name'] ?></a></p>
                            </div>
                            <h6 class="product-name">
                            <a href="<?= base_url($data1['p_id'].'/'.urlencode($data1['p_name'])) ?>"><?= $data1['p_name'] ?></a>
                            </h6>
                            <div class="price-box">
                                <span class="price-regular"><i class="fa fa-inr" aria-hidden="true"></i><?= round(($data1[$data1['p_carat']] * $data1['p_gram'] + $data1['p_other'] + $data1['p_l_char']) * 1.03) ?></span>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php
include_once('why_choose.php');
include_once('include/footer.php')
?>