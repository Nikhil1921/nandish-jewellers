<?php include('include/header.php') ?>
<section class="slider-area">
    <div class="hero-slider-active slick-arrow-style slick-arrow-style_hero slick-dot-style">
        
        <?php
        $sql_banner = "SELECT * from banner WHERE b_cat_id = 0 ORDER BY b_id DESC LIMIT 3";
        $run_banner = mysqli_query($connect,$sql_banner);
        while ($banner = mysqli_fetch_assoc($run_banner)):
        ?>
        <div class="hero-single-slide">
            <div class="hero-slider-item bg-img">
                <img src="<?= base_url() ?>admin/image/banner/<?= $banner['b_image']; ?>">
            </div>
        </div>
        <?php endwhile ?>
        
    </div>
</section>
<section class="product-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-12">
                
                <div class="section-title text-center">
                    <h2 class="title">Jewellery Colletion</h2>
                    <p class="sub-title">Leading Jewellery Brand For Over 100 Years</p>
                </div>
                
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="product-container">
                    
                    <div class="product-tab-menu">
                        <ul class="nav justify-content-center">
                            <li><a href="#tab1" class="active" data-toggle="tab">All</a></li>
                            <?php
                            $pro = "SELECT * FROM category";
                            $pro_run = mysqli_query($connect,$pro);
                            while ($pro_data = mysqli_fetch_assoc($pro_run))
                            {
                            ?>
                            <li><a href="#<?= $pro_data['c_name']; ?>" data-toggle="tab"><?= $pro_data['c_name']; ?></a></li>
                            <?php } ?>
                        </ul>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="tab1">
                            <div class="product-carousel-4_2 slick-row-10 slick-arrow-style">
                                <?php
                                $sql_prod = "SELECT * from innercategory";
                                $run_prod = mysqli_query($connect,$sql_prod);
                                while ($product = mysqli_fetch_assoc($run_prod)):
                                ?>
                                <div class="product-item">
                                    <figure class="category-thumb">
                                        <a href="<?= base_url() ?>product_list.php?pli=<?= $product['i_id']; ?>">
                                            <?php if (file_exists("admin/image/category/".$product['i_image']) && !is_dir("admin/image/category/".$product['i_image'])): ?>
                                            <img class="pri-img" src="<?= base_url() ?>admin/image/category/<?= $product['i_image'] ?>" alt="jewellery">
                                            <?php else: ?>
                                            <img class="pri-img" src="<?= base_url() ?>admin/image/noproduct.png" alt="jewellery">
                                            <?php endif ?>
                                        </a>
                                    </figure>
                                    <div class="product-caption text-center">
                                        <h6 class="product-name">
                                        <a href="<?= base_url() ?>product_list.php?pli=<?= $product['i_id']; ?>"><?= $product['i_name'] ?></a>
                                        </h6>
                                        
                                    </div>
                                </div>
                                <?php endwhile ?>
                            </div>
                        </div>
                        <?php
                        $pro1 = "SELECT * FROM category";
                        $pro_run1 = mysqli_query($connect,$pro1);
                        while ($pro_data1 = mysqli_fetch_assoc($pro_run1))
                        {
                        ?>
                        <div class="tab-pane fade" id="<?= $pro_data1['c_name']; ?>">
                            <div class="product-carousel-4_2 slick-row-10 slick-arrow-style">
                                <?php
                                $ca_name = $pro_data1['c_name'];
                                $cat = "SELECT * FROM category where c_name = '$ca_name'";
                                $cat_run1 = mysqli_query($connect,$cat);
                                $data_cat = mysqli_fetch_assoc($cat_run1);
                                $c_id = $data_cat['c_id'];
                                $sql_prod = "SELECT * from innercategory
                                where i_cat_id = '$c_id'";
                                $run_prod = mysqli_query($connect,$sql_prod);
                                while ($product = mysqli_fetch_assoc($run_prod)):
                                ?>
                                <div class="product-item">
                                    <figure class="category-thumb">
                                        <a href="<?= base_url() ?>product_list.php?pli=<?= $product['i_id'] ?>">
                                            <?php if (file_exists("admin/image/category/".$product['i_image']) && !is_dir("admin/image/category/".$product['i_image'])): ?>
                                            <img class="pri-img" src="<?= base_url() ?>admin/image/category/<?= $product['i_image'] ?>" alt="jewellery">
                                            <?php else: ?>
                                            <img class="pri-img" src="<?= base_url() ?>admin/image/noproduct.png" alt="jewellery">
                                            <?php endif ?>
                                        </a>
                                    </figure>
                                    <div class="product-caption text-center">
                                        <h6 class="product-name">
                                        <a href="<?= base_url() ?>product_list.php?pli=<?= $product['i_id'] ?>"><?= $product['i_name'] ?></a>
                                        </h6>
                                    </div>
                                </div>
                                <?php endwhile ?>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<section class="group-product-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-12">
                
                <div class="section-title text-center">
                    <h2 class="title">New Arrivals</h2>
                    <p class="sub-title">Crafted By Seasoned Craftsman</p>
                </div>
                
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="group-list-carousel--3 slick-row-10 slick-arrow-style">
                    
                    <?php
                    $sql_ne = "SELECT * from product p join category c on c.c_id = p.p_cat where p_show = 'New' AND p_qty_avail > 0";
                    $run_ne = mysqli_query($connect,$sql_ne);
                    while($data_ne = mysqli_fetch_assoc($run_ne))
                    {
                    $img = explode(',', $data_ne['p_image']);
                    ?>
                    <div class="group-slide-item">
                        <div class="group-item">
                            <div class="group-item-thumb">
                                <a href="<?= base_url($data_ne['p_id'].'/'.urlencode($data_ne['p_name'])) ?>">
                                    <?php if (file_exists("admin/image/product/".reset($img)) && !is_dir("admin/image/product/".reset($img))): ?>
                                    <img src="<?= base_url() ?>admin/image/product/<?= reset($img) ?>" alt="jewellery">
                                    <?php else: ?>
                                    <img src="<?= base_url() ?>admin/image/logo.png" alt="jewellery">
                                    <?php endif ?>
                                </a>
                            </div>
                            <div class="group-item-desc">
                                <h5 class="group-product-name"><a href="<?= base_url($data_ne['p_id'].'/'.urlencode($data_ne['p_name'])) ?>"><?= $data_ne['p_name']; ?></a></h5>
                                <div class="price-box">
                                    <span class="price-regular"><i class="fa fa-inr" aria-hidden="true"></i><?= round(($data_ne[$data_ne['p_carat']] * $data_ne['p_gram'] + $data_ne['p_other'] + $data_ne['p_l_char']) * 1.03) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<section class="product-banner-statistics section-padding">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <!-- section title start -->
                <div class="section-title text-center">
                    <h2 class="title">Best Category</h2>
                </div>
                <!-- section title start -->
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="product-banner-carousel slick-row-10">
                    <!-- banner single slide start -->
                    <?php
                    $sql_cat = "SELECT * FROM innercategory where i_show = 'Best'";
                    $run_cat = mysqli_query($connect,$sql_cat);
                    while($data_cat=mysqli_fetch_assoc($run_cat))
                    {
                    ?>
                    <div class="banner-slide-item">
                        <figure class="banner-statistics">
                            <a href="<?= base_url() ?>product_list.php?pli=<?= $data_cat['i_id'] ?>">
                                <?php if (file_exists("admin/image/category/".$data_cat['i_image']) && !is_dir("admin/image/category/".$data_cat['i_image'])): ?>
                                <img src="<?= base_url() ?>admin/image/category/<?= $data_cat['i_image'] ?>" alt="jewellery">
                                <?php else: ?>
                                <img src="<?= base_url() ?>admin/image/noproduct.png" alt="jewellery">
                                <?php endif ?>
                            </a>
                            <div class="banner-content banner-content_style2">
                                <h5 class="banner-text3"><a href="<?= base_url() ?>product_list.php?pli=<?= $data_cat['i_id'] ?>"><?= $data_cat['i_name'] ?></a></h5>
                            </div>
                        </figure>
                    </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="group-product-area section-padding">
    <div class="container">
        
        <div class="row">
                <div class="col-12">
                    <!-- section title start -->
                    <div class="section-title text-center">
                        <h2 class="title">Best Jewellery</h2>
                    </div>
                    <!-- section title start -->
                </div>
        </div>
        
        <div class="row">
            <?php
            $sql_cat = "SELECT c_id, c_name FROM category LIMIT 2";
            $run_cat = mysqli_query($connect, $sql_cat);
            while ($c = mysqli_fetch_assoc($run_cat)):
            $c = (object) $c; ?>
            <div class="col-lg-6 section-padding">
                <div class="categories-group-wrapper">
                    <div class="section-title-append">
                        <h4>best Jewellery in <?= $c->c_name ?></h4>
                        <div class="slick-append"></div>
                    </div>
                    <div class="group-list-item-wrapper" >
                        <div class="group-list-carousel" >
                            <?php
                            $sql_best = "SELECT * FROM product p join category c on c.c_id = p.p_cat where p_show = 'Best' AND p_qty_avail > 0 AND p_cat = '$c->c_id' ORDER BY p_id LIMIT 8";
                            $run_best = mysqli_query($connect,$sql_best);
                            while ($best = mysqli_fetch_assoc($run_best)):
                            $imge = explode(",", $best['p_image']);
                            ?>
                            <div class="group-slide-item" >
                                <div class="group-item">
                                    <div class="group-item-thumb">
                                        <a href="<?= base_url($best['p_id'].'/'.urlencode($best['p_name'])) ?>">
                                            <?php if (file_exists("admin/image/product/".reset($imge)) && !is_dir("admin/image/product/".reset($imge))): ?>
                                            <img src="<?= base_url() ?>admin/image/product/<?= reset($imge) ?>" alt="jewellery">
                                            <?php else: ?>
                                            <img src="<?= base_url() ?>admin/image/logo.png" alt="jewellery">
                                            <?php endif ?>
                                        </a>
                                    </div>
                                    <div class="group-item-desc" >
                                        <h5 class="group-product-name"><a href="<?= base_url($best['p_id'].'/'.urlencode($best['p_name'])) ?>"><?= $best['p_name']; ?></a></h5>
                                        <div class="price-box">
                                            <span class="price-regular"><i class="fa fa-inr" aria-hidden="true"></i><?= round(($best[$best['p_carat']] * $best['p_gram'] + $best['p_other'] + $best['p_l_char']) * 1.03) ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile ?>
        </div>
    </div>
</section>
<section class="testimonial-section" >
    <!-- section title start -->
    <div class="section-title text-center">
        <h2 class="title">Owners Message</h2>
        <p class="sub-title text-capitalize">What they say</p>
    </div>
    <div class=" bg-color">
        <!--<img class="bg-img" src="<?= base_url() ?>img/testimonial/testimonials-bg.png">-->
        <div class="testimonial">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="testimonial-thumb-wrapper">
                        <div class="testimonial-thumb-carousel">
                            <?php
                            $sql_te = "SELECT * FROM testimonial";
                            $run_te = mysqli_query($connect,$sql_te);
                            while($data_te = mysqli_fetch_assoc($run_te))
                            {
                            ?>
                            <div class="testimonial-thumb">
                                <img src="<?= base_url() ?>admin/image/testimonial/<?= $data_te['t_image'] ?>" alt="testimonial-thumb">
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="testimonial-content-wrapper">
                        <div class="testimonial-content-carousel">
                            <?php
                            $sql_tes = "SELECT * FROM testimonial";
                            $run_tes = mysqli_query($connect,$sql_tes);
                            while($data_tes = mysqli_fetch_assoc($run_tes))
                            {
                            ?>
                            <div class="testimonial-content">
                                <h5 class="testimonial-author"><?= $data_tes['t_name'] ?></h5>
                                <p>
                                    <?= $data_tes['t_detail'] ?>
                                </p>
                                
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</section>
<?php
include_once('why_choose.php');
include_once('include/footer.php')
?>