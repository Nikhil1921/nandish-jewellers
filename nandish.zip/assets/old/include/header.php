<?php
   include("../../admin/layout/connect.php");
   session_start();
   if(!empty($_SESSION['id']))
   {
      $id = $_SESSION['id'];
   }
   ?>
<!DOCTYPE html>
<html class="no-js" lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="x-ua-compatible" content="ie=edge">
      <title>Nandish Jewellers</title>
      <meta name="robots" content="noindex, follow" />
      <meta name="description" content="">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="shortcut icon" type="image/x-icon" href="<?= base_url() ?>admin/image/logo.png">
      <link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700,900" rel="stylesheet">
      <link rel="stylesheet" href="../../assets/css/vendor/bootstrap.min.css">
      <link rel="stylesheet" href="../../assets/css/vendor/pe-icon-7-stroke.css">
      <link rel="stylesheet" href="../../assets/css/vendor/font-awesome.min.css">
      <link rel="stylesheet" href="../../assets/css/plugins/slick.min.css">
      <link rel="stylesheet" href="../../assets/css/plugins/animate.css">
      <link rel="stylesheet" href="../../assets/css/plugins/nice-select.css">
      <link rel="stylesheet" href="../../assets/css/plugins/jqueryui.min.css">
      <link rel="stylesheet" href="../../assets/css/style.css">
      <link rel="stylesheet" href="../../assets/css/custom.css">
      <link rel="stylesheet" href="../../assets/css/responsive.css">
   </head>
   <body>
      <header class="header-area">
         <div class="main-header d-none d-lg-block">
            <div class="header-main-area sticky">
               <div class="container-fluid">
                  <div class="row align-items-center ptb-30">
                     <div class="col-lg-4">
                        <div class="header-social-link">
                           <a href="https://api.whatsapp.com/send?phone=918000104444&text=Hello" target="_blank"><i class="fa fa-whatsapp"></i></a>
                           <a href="https://www.instagram.com/nandish.in/"><i class="fa fa-instagram"></i></a>
                           <a href="https://www.facebook.com/nandishjewellers/"><i class="fa fa-facebook"></i></a>
                           <a href="https://twitter.com/NandishJewelers"><i class="fa fa-twitter"></i></a>
                           <a href="https://www.linkedin.com/company/nandishjewellers"><i class="fa fa-linkedin"></i></a>
                           <a href="https://www.pinterest.com/nandishjewellers/"><i class="fa fa-pinterest"></i></a>
                           <a href="https://nandishjewellers.tumblr.com/"><i class="fa fa-tumblr"></i></a>
                           <a href="https://www.youtube.com/channel/UCvfGeR0YCu38rJmv4ZF1kXg"><i class="fa fa-youtube-play"></i></a>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class=" logo Absolute-Center">
                           <a href="<?= base_url() ?>">
                           <img src="<?= base_url() ?>img/logo/logo.png" alt="Brand Logo">
                           </a>
                        </div>
                     </div>
                     <div class="col-lg-4">
                        <div class="header-right d-flex align-items-center justify-content-end">
                           <div class="header-configure-area">
                              <ul class="nav justify-content-end">
                                 <li class="header-search-container mr-0">
                                    <button class="search-trigger d-block"><i class="pe-7s-search"></i></button>
                                    <form class="header-search-box d-none animated jackInTheBox" action="<?= base_url('product_list.php') ?>">
                                       <?php if (isset($_GET['pli'])): ?>
                                       <input type="hidden" name="pli" value="<?= $_GET['pli'] ?>">  
                                       <?php endif ?>
                                       <input type="text" placeholder="Search entire store hire" name="search" class="header-search-field">
                                       <button class="header-search-btn"><i class="pe-7s-search"></i></button>
                                    </form>
                                 </li>
                                 <li>
                                    <a href="tel:+918000104444">
                                       <div class="menu-svg">
                                          <svg  xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="40px" height="45px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                                             viewBox="0 43 258 261"
                                             xmlns:xlink="http://www.w3.org/1999/xlink">
                                             <defs>
                                                <style type="text/css">
                                                   <![CDATA[
                                                      .fil0 {fill:#5f5aa5}
                                                      ]]>
                                                </style>
                                             </defs>
                                             <g id="Layer_x0020_1">
                                                <metadata id="CorelCorpID_0Corel-Layer"/>
                                                <g id="_549274504">
                                                   <path  class="bag" d="M164 48l-70 0c-6,0 -12,5 -12,12l0 141c0,6 6,12 12,12l70 0c6,0 12,-6 12,-12l0 -141c0,-7 -6,-12 -12,-12zm-52 7l34 0c1,0 2,1 2,3 0,1 -1,3 -2,3l-34 0c-1,0 -2,-2 -2,-3 0,-2 1,-3 2,-3zm17 146c-4,0 -8,-3 -8,-8 0,-4 4,-7 8,-7 4,0 8,3 8,7 0,5 -4,8 -8,8zm38 -26l-76 0 0 -107 76 0 0 107z"/>
                                                </g>
                                             </g>
                                          </svg>
                                       </div>
                                    </a>
                                 </li>
                                 <li class="user-hover">
                                    <a href="#">
                                       <div class="menu-svg">
                                          <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 350 350" class="bag" xml:space="preserve">
                                             <g>
                                             <path d="M175,171.173c38.914,0,70.463-38.318,70.463-85.586C245.463,38.318,235.105,0,175,0s-70.465,38.318-70.465,85.587
                                                C104.535,132.855,136.084,171.173,175,171.173z"/>
                                             <path d="M41.909,301.853C41.897,298.971,41.885,301.041,41.909,301.853L41.909,301.853z"/>
                                             <path d="M308.085,304.104C308.123,303.315,308.098,298.63,308.085,304.104L308.085,304.104z"/>
                                             <path d="M307.935,298.397c-1.305-82.342-12.059-105.805-94.352-120.657c0,0-11.584,14.761-38.584,14.761
                                                s-38.586-14.761-38.586-14.761c-81.395,14.69-92.803,37.805-94.303,117.982c-0.123,6.547-0.18,6.891-0.202,6.131
                                                c0.005,1.424,0.011,4.058,0.011,8.651c0,0,19.592,39.496,133.08,39.496c113.486,0,133.08-39.496,133.08-39.496
                                                c0-2.951,0.002-5.003,0.005-6.399C308.062,304.575,308.018,303.664,307.935,298.397z"/>
                                          </svg>
                                       </div>
                                    </a>
                                    <ul class="dropdown-list">
                                       <?php
                                          if(empty($_SESSION['id']))
                                          {
                                          ?>
                                       <li><a href="<?= base_url() ?>login-register.php">login</a></li>
                                       <li><a href="<?= base_url() ?>login-register.php">register</a></li>
                                       <?php }else{ ?>
                                       <li><a href="<?= base_url() ?>my-account.php">my account</a></li>
                                       <li><a href="<?= base_url() ?>logout.php">Logout</a></li>
                                       <?php } ?>
                                    </ul>
                                 </li>
                                 <li>
                                    <a href="<?= base_url() ?>wishlist.php">
                                       <div class="menu-svg">
                                          <div class="notification-nic">
                                             <?php
                                       if(!empty($_SESSION['id']))
                                       {
                                       $id = $_SESSION['id'];
                                       $sql_wis = "SELECT * FROM wish where w_u_id = '$id'";
                                       $run_wis = mysqli_query($connect,$sql_wis);
                                       $wish = mysqli_num_rows($run_wis);
                                       echo $wish;
                                       }
                                       else
                                       {
                                       echo "0";
                                       }
                                       ?>
                                          </div>
                                          <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                             viewBox="0 0 455 455" class="bag" xml:space="preserve">
                                             <path d="M326.632,10.346c-38.733,0-74.991,17.537-99.132,46.92c-24.141-29.383-60.399-46.92-99.132-46.92
                                                C57.586,10.346,0,67.931,0,138.714c0,55.426,33.049,119.535,98.23,190.546c50.162,54.649,104.729,96.96,120.257,108.626l9.01,6.769
                                                l9.009-6.768c15.53-11.667,70.099-53.979,120.26-108.625C421.95,258.251,455,194.141,455,138.714
                                                C455,67.931,397.414,10.346,326.632,10.346z"/>
                                             </svg>
                                          </div>
                                       </a>
                                    </li>
                                 <li>
                                    <a href="#" class="minicart-btn">
                                       <div class="menu-svg">
                                          <div class="notification-nic">
                                             <?php
                                                if(!empty($_SESSION['id']))
                                                {
                                                $id = $_SESSION['id'];
                                                $sql_wis = "SELECT * FROM cart where ca_u_id = '$id'";
                                                $run_wis = mysqli_query($connect,$sql_wis);
                                                $cart = mysqli_num_rows($run_wis);
                                                echo $cart;
                                                }
                                                else
                                                {
                                                echo "0";
                                                }
                                                ?>
                                          </div>
                                          <svg version="1.1" id="Capa_1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                             viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" class="bag">
                                             <path d="M443.209,442.24l-27.296-299.68c-0.736-8.256-7.648-14.56-15.936-14.56h-48V96c0-25.728-9.984-49.856-28.064-67.936
                                                C306.121,10.24,281.353,0,255.977,0c-52.928,0-96,43.072-96,96v32h-48c-8.288,0-15.2,6.304-15.936,14.56L68.809,442.208
                                                c-1.632,17.888,4.384,35.712,16.48,48.96S114.601,512,132.553,512h246.88c17.92,0,35.136-7.584,47.232-20.8
                                                C438.793,477.952,444.777,460.096,443.209,442.24z M319.977,128h-128V96c0-35.296,28.704-64,64-64
                                                c16.96,0,33.472,6.784,45.312,18.656C313.353,62.72,319.977,78.816,319.977,96V128z"/>
                                          </svg>
                                       </div>
                                    </a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-12">
                        <div class="main-menu-area ">
                           <div class="main-menu">
                              <nav class="row desktop-menu ptb-40">
                                 <div class="col-6">
                                    <ul class="justify-content-left header-style-4">
                                       <li class="active"><a href="<?= base_url() ?>">Home</a></li>
                                       <?php
                                          $cat_menu = "SELECT * from category";
                                          $cat_run = mysqli_query($connect,$cat_menu);
                                          while($cat_data=mysqli_fetch_assoc($cat_run))
                                          {
                                          ?>
                                       <li class="position-static">
                                          <a href="#"><?= $cat_data['c_name']; ?><i
                                             class="fa fa-angle-down"></i></a>
                                          <ul class="megamenu dropdown">
                                             <?php
                                                $ca_menu = $cat_data['c_id'];
                                                $sub_menu = "SELECT * from subcategory where sc_c_id = '$ca_menu'";
                                                $sub_run = mysqli_query($connect,$sub_menu);
                                                while($sub_data=mysqli_fetch_assoc($sub_run))
                                                {
                                                ?>
                                             <li class="mega-title">
                                                <span><?= $sub_data['sc_name'] ?></span>
                                                <ul>
                                                   <?php
                                                      $sc_menu = $sub_data['sc_id'];
                                                      $inn_menu = "SELECT * from innercategory  where i_sub_id = '$sc_menu'";
                                                      $inn_run = mysqli_query($connect,$inn_menu);
                                                      while($inn_data=mysqli_fetch_assoc($inn_run))
                                                      {
                                                      ?>
                                                   <li><a href="<?= base_url() ?>product_list.php?pli=<?= $inn_data['i_id']; ?>"><?= $inn_data['i_name'] ?></a></li>
                                                   <?php } ?>
                                                </ul>
                                             </li>
                                             <?php } ?>
                                          </ul>
                                       </li>
                                       <?php } ?>
                                    </ul>
                                 </div>
                                 <div class="col-6">
                                    <ul class="justify-content-end header-style-4">
                                       <li>
                                          <?php
                                             $sql_mtl = "SELECT * From category where c_name = 'Gold'";
                                             $run_mtl = mysqli_query($connect,$sql_mtl);
                                             $data_mtl=mysqli_fetch_assoc($run_mtl);
                                             $sql_mtl2 = "SELECT * From category where c_name = 'Silver'";
                                             $run_mtl2 = mysqli_query($connect,$sql_mtl2);
                                             $data_mtl2=mysqli_fetch_assoc($run_mtl2);
                                             ?>
                                          <a href="#">Metal Rate<i
                                             class="fa fa-angle-down"></i></a>
                                          <ul class="dropdown metal-table">
                                             <li>
                                                <table class="table-bordered metal-rate-table">
                                                   <tr class="table-header">
                                                      <td>Purity</td>
                                                      <td>Metal</td>
                                                      <td>Rate</td>
                                                   </tr>
                                                   <tr>
                                                      <td>24 Carat (999)</td>
                                                      <td>Gold 1g</td>
                                                      <td><?= $data_mtl['c_price']; ?></td>
                                                   </tr>
                                                   <tr>
                                                      <td>22 Caret (916)</td>
                                                      <td>Gold 1g</td>
                                                      <td><?= $data_mtl['c_price_22']; ?></td>
                                                   </tr>
                                                   <tr>
                                                      <td>18 Carat (750)</td>
                                                      <td>Gold 1g</td>
                                                      <td><?= $data_mtl['c_price_18']; ?></td>
                                                   </tr>
                                                   <tr>
                                                      <td>24 Carat (999)</td>
                                                      <td>Silver 1g</td>
                                                      <td><?= $data_mtl2['c_price']; ?></td>
                                                   </tr>
                                                   <tr>
                                                      <td>22 Carat (925)</td>
                                                      <td> Silver 1g</td>
                                                      <td><?= $data_mtl2['c_price_22']; ?></td>
                                                   </tr>
                                                   <tr>
                                                      <td>18 Carat (750)</td>
                                                      <td>Silver 1g</td>
                                                      <td><?= $data_mtl2['c_price_18']; ?></td>
                                                   </tr>
                                                </table>
                                             </li>
                                          </ul>
                                       </li>
                                       <li><a href="<?= base_url() ?>about-us.php">About us </a></li>
                                       <li><a href="<?= base_url() ?>contact-us.php">Contact us</a></li>
                                    </ul>
                                 </div>
                              </nav>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="mobile-header d-lg-none d-md-block sticky">
            <div class="container-fluid">
               <div class="row align-items-center">
                  <div class="col-12">
                     <div class="mobile-main-header">
                        <div class="mobile-menu-icon ">
                           <div class="menu-svg">
                              <a href="tel:+91 80001 04444">
                                 <svg  xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="20px" height="25px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                                    viewBox="45 0 180 230"
                                    xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <defs>
                                       <style type="text/css">
                                          <![CDATA[
                                             .fil0 {fill:#5f5aa5}
                                             ]]>
                                       </style>
                                    </defs>
                                    <g id="Layer_x0020_1">
                                       <metadata id="CorelCorpID_0Corel-Layer"/>
                                       <g id="_549274504">
                                          <path  class="bag" d="M164 48l-70 0c-6,0 -12,5 -12,12l0 141c0,6 6,12 12,12l70 0c6,0 12,-6 12,-12l0 -141c0,-7 -6,-12 -12,-12zm-52 7l34 0c1,0 2,1 2,3 0,1 -1,3 -2,3l-34 0c-1,0 -2,-2 -2,-3 0,-2 1,-3 2,-3zm17 146c-4,0 -8,-3 -8,-8 0,-4 4,-7 8,-7 4,0 8,3 8,7 0,5 -4,8 -8,8zm38 -26l-76 0 0 -107 76 0 0 107z"/>
                                       </g>
                                    </g>
                                 </svg>
                              </a>
                           </div>
                           <div class="user-hover">
                              <a href="#">
                                 <div class="menu-svg">
                                    <svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 350 350" class="bag" xml:space="preserve">
                                       <g>
                                       <path d="M175,171.173c38.914,0,70.463-38.318,70.463-85.586C245.463,38.318,235.105,0,175,0s-70.465,38.318-70.465,85.587
                                          C104.535,132.855,136.084,171.173,175,171.173z"/>
                                       <path d="M41.909,301.853C41.897,298.971,41.885,301.041,41.909,301.853L41.909,301.853z"/>
                                       <path d="M308.085,304.104C308.123,303.315,308.098,298.63,308.085,304.104L308.085,304.104z"/>
                                       <path d="M307.935,298.397c-1.305-82.342-12.059-105.805-94.352-120.657c0,0-11.584,14.761-38.584,14.761
                                          s-38.586-14.761-38.586-14.761c-81.395,14.69-92.803,37.805-94.303,117.982c-0.123,6.547-0.18,6.891-0.202,6.131
                                          c0.005,1.424,0.011,4.058,0.011,8.651c0,0,19.592,39.496,133.08,39.496c113.486,0,133.08-39.496,133.08-39.496
                                          c0-2.951,0.002-5.003,0.005-6.399C308.062,304.575,308.018,303.664,307.935,298.397z"/>
                                    </svg>
                                 </div>
                              </a>
                              <ul class="dropdown-list">
                                 <li><a href="<?= base_url() ?>login-register.php">login</a></li>
                                 <li><a href="<?= base_url() ?>login-register.php">register</a></li>
                                 <li><a href="<?= base_url() ?>my-account.php">my account</a></li>
                              </ul>
                           </div>
                           <div class="mini-cart-wrap">
                              <a href="<?= base_url() ?>cart.php">
                                 <div class="menu-svg">
                                    <div class="notification-nic1">
                                       <?php
                                          if(!empty($_SESSION['id']))
                                          {
                                          $id = $_SESSION['id'];
                                          $sql_wis = "SELECT * FROM cart where ca_u_id = '$id'";
                                          $run_wis = mysqli_query($connect,$sql_wis);
                                          $wish = mysqli_num_rows($run_wis);
                                          echo $wish;
                                          }
                                          else
                                          {
                                          echo "0";
                                          }
                                          ?>
                                    </div>
                                    <svg version="1.1" id="Capa_1"  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                       viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve" class="bag">
                                       <path d="M443.209,442.24l-27.296-299.68c-0.736-8.256-7.648-14.56-15.936-14.56h-48V96c0-25.728-9.984-49.856-28.064-67.936
                                          C306.121,10.24,281.353,0,255.977,0c-52.928,0-96,43.072-96,96v32h-48c-8.288,0-15.2,6.304-15.936,14.56L68.809,442.208
                                          c-1.632,17.888,4.384,35.712,16.48,48.96S114.601,512,132.553,512h246.88c17.92,0,35.136-7.584,47.232-20.8
                                          C438.793,477.952,444.777,460.096,443.209,442.24z M319.977,128h-128V96c0-35.296,28.704-64,64-64
                                          c16.96,0,33.472,6.784,45.312,18.656C313.353,62.72,319.977,78.816,319.977,96V128z"/>
                                    </svg>
                                 </div>
                              </a>
                           </div>
                        </div>

                        <div class="mobile-logo">
                           <a href="<?= base_url() ?>">
                           <img src="<?= base_url() ?>img/logo/logo.png" alt="Brand Logo">
                           </a>
                        </div>
                        <div class="mobile-menu-toggler">
                           
                           <button class="mobile-menu-btn">
                           <span></span>
                           <span></span>
                           <span></span>
                           </button>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <aside class="off-canvas-wrapper">
            <div class="off-canvas-overlay"></div>
            <div class="off-canvas-inner-content">
               <div class="btn-close-off-canvas">
                  <i class="pe-7s-close"></i>
               </div>
               <div class="off-canvas-inner">
                  <div class="search-box-offcanvas">
                     <form action="<?= base_url() ?>product_list.php">
                        <?php if (isset($_GET['pli'])): ?>
                        <input type="hidden" name="pli" value="<?= $_GET['pli'] ?>">
                        <?php endif ?>
                        <input type="text" placeholder="Search here..." name="search">
                        <button class="search-btn"><i class="pe-7s-search"></i></button>
                     </form>
                  </div>
                  <div class="mobile-navigation">
                     <nav>
                        <ul class="mobile-menu">
                           <li><a href="<?= base_url() ?>">Home</a></li>
                              <?php
                              $cat_menu = "SELECT * from category";
                              $cat_run = mysqli_query($connect,$cat_menu);
                              while($cat_data=mysqli_fetch_assoc($cat_run))
                              {
                              ?>
                           <li class="menu-item-has-children">
                              <a href="#"><?= $cat_data['c_name']; ?></a>
                              <ul class="megamenu dropdown">
                                 <?php
                                    $ca_menu = $cat_data['c_id'];
                                    $sub_menu = "SELECT * from subcategory where sc_c_id = '$ca_menu'";
                                    $sub_run = mysqli_query($connect,$sub_menu);
                                    while($sub_data=mysqli_fetch_assoc($sub_run))
                                    {
                                    ?>
                                 <li class="mega-title menu-item-has-children">
                                    <a href="#"><?= $sub_data['sc_name'] ?></a>
                                    <ul class="dropdown">
                                       <?php
                                          $sc_menu = $sub_data['sc_id'];
                                          $inn_menu = "SELECT * from innercategory  where i_sub_id = '$sc_menu'";
                                          $inn_run = mysqli_query($connect,$inn_menu);
                                          while($inn_data=mysqli_fetch_assoc($inn_run))
                                          {
                                          ?>
                                       <li><a href="<?= base_url() ?>product_list.php?pli=<?= $inn_data['i_id']; ?>"><?= $inn_data['i_name'] ?></a></li>
                                       <?php } ?>
                                    </ul>
                                 </li>
                                 <?php } ?>
                              </ul>
                           </li>
                           <?php } ?>
                           <li class="menu-item-has-children">
                              <a href="#">Metal Rate</a>
                              <ul class="megamenu dropdown">
                                 <li class="mega-title menu-item-has-children">
                                    <table class="table-bordered metal-rate-table">
                                       <tr>
                                          <td>Purity</td>
                                          <td>Metal</td>
                                          <td>Rate</td>
                                       </tr>
                                       <tr>
                                          <td>24 Carat (999)</td>
                                          <td>Gold 1g</td>
                                          <td><?= $data_mtl['c_price']; ?></td>
                                       </tr>
                                       <tr>
                                          <td>22 Caret (916)</td>
                                          <td>Gold 1g</td>
                                          <td><?= $data_mtl['c_price_22']; ?></td>
                                       </tr>
                                       <tr>
                                          <td>18 Carat (750)</td>
                                          <td>Gold 1g</td>
                                          <td><?= $data_mtl['c_price_18']; ?></td>
                                       </tr>
                                       <tr>
                                          <td>24 Carat (999)</td>
                                          <td>Silver 1g</td>
                                          <td><?= $data_mtl2['c_price']; ?></td>
                                       </tr>
                                       <tr>
                                          <td>22 Carat (925)</td>
                                          <td> Silver 1g</td>
                                          <td><?= $data_mtl2['c_price_22']; ?></td>
                                       </tr>
                                       <tr>
                                          <td>18 Carat (750)</td>
                                          <td>Silver 1g</td>
                                          <td><?= $data_mtl2['c_price_18']; ?></td>
                                       </tr>
                                    </table>
                                 </li>
                              </ul>
                           </li>
                           
                        </ul>
                     </nav>
                  </div>
                  <div class="offcanvas-widget-area">
                     <div class="off-canvas-contact-widget">
                        <div class="mobile-settings">
                     <ul class="nav">
                        <li>
                           <div class="dropdown mobile-top-dropdown">
                              <a href="#" class="dropdown-toggle" id="myaccount" data-toggle="dropdown"
                                 aria-haspopup="true" aria-expanded="false">
                              My Account
                              <i class="fa fa-angle-down"></i>
                              </a>
                              <div class="dropdown-menu" aria-labelledby="myaccount">
                                 <?php
                                    if(!empty($_SESSION['id']))
                                    {
                                    ?>
                                 <a class="dropdown-item" href="<?= base_url() ?>my-account.php">my account</a>
                                 <?php }else{ ?>
                                 <a class="dropdown-item" href="<?= base_url() ?>login-register.php"> login</a>
                                 <a class="dropdown-item" href="<?= base_url() ?>login-register.php">register</a>
                                 <?php } ?>
                              </div>
                           </div>
                        </li>
                        <li><a href="<?= base_url() ?>wishlist.php">Wishlist</a></li>
                           <li><a href="<?= base_url() ?>about-us.php">About us</a></li>
                           <li><a href="<?= base_url() ?>contact-us.php">Contact us</a></li>
                           <li>
                              <span class="menu-svg">
                                 <svg  xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="25px" height="25px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                                    viewBox="45 0 150 240"
                                    xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <defs>
                                       <style type="text/css">
                                          <![CDATA[
                                             .fil0 {fill:#5f5aa5}
                                             ]]>
                                       </style>
                                    </defs>
                                    <g id="Layer_x0020_1">
                                       <metadata id="CorelCorpID_0Corel-Layer"/>
                                       <g id="_549274504">
                                          <path  class="bag" d="M164 48l-70 0c-6,0 -12,5 -12,12l0 141c0,6 6,12 12,12l70 0c6,0 12,-6 12,-12l0 -141c0,-7 -6,-12 -12,-12zm-52 7l34 0c1,0 2,1 2,3 0,1 -1,3 -2,3l-34 0c-1,0 -2,-2 -2,-3 0,-2 1,-3 2,-3zm17 146c-4,0 -8,-3 -8,-8 0,-4 4,-7 8,-7 4,0 8,3 8,7 0,5 -4,8 -8,8zm38 -26l-76 0 0 -107 76 0 0 107z"/>
                                       </g>
                                    </g>
                                 </svg>
                              </span>
                              <a href="tel:+91 80001 04444">+91 80001 04444</a>
                           </li>
                           <li>
                              <span>
                                 <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="25px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                                    viewBox="0 0 340 343"
                                    xmlns:xlink="http://www.w3.org/1999/xlink">
                                    <polygon fill="#5f5aa5" points="151,189 111,230 160,195 "/>
                                    <polygon  fill="#5f5aa5" points="243,96 243,103 170,155 98,103 98,96 67,96 67,248 98,248 98,148 81,133 98,146 98,145 112,156 131,170 131,170 170,198 209,170 209,170 228,156 243,145 243,146 259,133 243,148 243,246 273,246 273,96 "/>
                                    <polygon  fill="#5f5aa5" points="188,190 229,230 181,195 "/>
                                    <path fill="#5f5aa5" d="M273 247l-206 0 0 -152 206 0 0 152zm-8 -144l-191 0 0 137 191 0 0 -137 0 0z"/>
                                 </svg>
                              </span>
                              <a href="mailto:nandish.jewellers@gmail.com">nandish.jewellers@gmail.com</a>
                           </li>
                     </ul>
                  </div>
                     </div>
                     <div class="off-canvas-social-widget social-links text-center">
                        <a target="_blank" href="https://api.whatsapp.com/send?phone=918000104444&text=Hello">
                           <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="30px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                              viewBox="0 0 194 195"
                              xmlns:xlink="http://www.w3.org/1999/xlink">
                              <path  d="M97 195c-54,0 -97,-43 -97,-98 0,-54 44,-98 98,-97 53,1 96,44 96,99 -1,53 -44,96 -97,96zm0 -187c-49,-1 -89,39 -89,89 -1,50 40,90 88,91 49,0 90,-39 90,-90 0,-50 -40,-90 -89,-90z"/>
                              <path  d="M36 161c2,-5 3,-10 5,-14 2,-6 4,-11 6,-17 0,-1 0,-2 -1,-3 -5,-9 -8,-19 -8,-30 1,-30 24,-55 53,-59 32,-3 60,18 66,49 6,32 -16,64 -48,69 -13,3 -26,1 -38,-5 -1,-1 -2,-1 -4,0 -9,3 -19,6 -28,9 -1,0 -2,0 -3,1zm16 -16c6,-2 11,-3 17,-5 1,-1 2,-1 3,0 11,7 23,9 36,6 30,-5 48,-38 36,-66 -11,-28 -41,-40 -68,-27 -17,9 -27,24 -27,44 -1,10 2,20 8,29 1,1 1,1 0,2 -1,4 -2,7 -3,11 -1,2 -1,4 -2,6z"/>
                              <path  d="M79 69c1,0 1,0 2,0 2,0 3,0 3,2 2,4 3,8 5,12 0,2 0,3 -1,4 -1,1 -2,3 -3,4 -1,1 -2,2 -1,3 5,9 12,15 21,19 1,0 2,0 3,-1 1,-2 3,-3 4,-5 1,-2 2,-2 4,-1 4,2 8,4 12,6 1,1 1,2 1,3 0,7 -4,10 -11,12 -3,1 -6,0 -9,0 -15,-5 -26,-14 -34,-27 -3,-4 -6,-8 -6,-14 -1,-6 1,-12 5,-16 2,-1 3,-2 5,-1z"/>
                           </svg>
                        </a>
                        <a href="https://www.instagram.com/nandish.in/">
                           <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="30px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                              viewBox="0 0 298 301"
                              xmlns:xlink="http://www.w3.org/1999/xlink">
                              <path  d="M149 301c-82,-1 -149,-67 -149,-152 0,-83 68,-150 151,-149 81,1 147,67 147,152 -1,82 -67,148 -149,149zm0 -289c-74,0 -136,60 -137,137 -1,78 61,139 135,140 76,1 139,-61 139,-137 0,-78 -61,-140 -137,-140z"/>
                              <g>
                              <path  d="M234 152c0,12 0,24 1,36 0,22 -14,39 -33,46 -6,2 -12,4 -19,4 -23,0 -46,0 -69,0 -19,-1 -34,-9 -45,-25 -4,-7 -6,-14 -6,-22 0,-26 0,-52 0,-78 1,-17 9,-30 23,-39 9,-5 19,-8 30,-8 22,0 45,0 67,0 18,1 33,8 43,22 6,8 8,16 8,25 0,13 0,26 0,39zm-158 0c0,13 0,25 0,38 0,5 1,10 3,14 8,14 20,21 36,21 22,0 44,0 67,0 6,0 11,-1 17,-3 14,-6 23,-18 23,-33 0,-25 0,-50 0,-75 0,-7 -2,-13 -6,-19 -9,-11 -20,-16 -33,-16 -23,0 -45,0 -68,0 -5,0 -10,1 -15,3 -14,5 -25,18 -24,35 0,11 0,23 0,35z"/>
                              <path  d="M149 109c22,0 40,18 40,40 0,22 -18,40 -40,40 -22,0 -40,-18 -40,-40 0,-22 18,-40 40,-40zm27 40c0,-15 -12,-27 -27,-27 -15,0 -28,12 -28,27 0,15 13,27 28,27 15,0 27,-12 27,-27z"/>
                              <path  d="M186 106c-1,-5 3,-9 8,-9 5,0 9,4 8,9 0,5 -4,9 -8,9 -5,0 -8,-4 -8,-9z"/>
                           </svg>
                        </a>
                        <a href="https://www.facebook.com/nandishjewellers/">
                           <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="30px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                              viewBox="0 0 234 234"
                              xmlns:xlink="http://www.w3.org/1999/xlink">
                              <path  d="M200 34c-21,-21 -51,-34 -83,-34 -32,0 -62,13 -83,34 -21,21 -34,51 -34,83 0,32 13,62 34,83 21,21 51,34 83,34 32,0 62,-13 83,-34 21,-21 34,-51 34,-83 0,-32 -13,-62 -34,-83zm-7 159c-19,20 -46,32 -76,32 -30,0 -57,-12 -76,-32 -20,-19 -32,-46 -32,-76 0,-30 12,-57 32,-76 19,-20 46,-32 76,-32 30,0 57,12 76,32 20,19 32,46 32,76 0,30 -12,57 -32,76z"/>
                              <g id="Facebook">
                              <path id="Facebook_1_"  d="M154 70l0 -23c-1,0 -2,0 -3,0 -2,0 -4,0 -6,0 -2,0 -5,0 -7,0 -3,0 -5,0 -7,0 -3,0 -7,0 -10,1 -3,1 -6,3 -8,5 -2,1 -3,2 -4,4 -1,0 -1,1 -2,1 -1,2 -2,5 -3,7 0,0 0,1 0,1 -1,4 -1,8 -1,12 0,1 0,1 0,2 0,7 0,18 0,18l-23 0 0 25 22 0 0 0 0 65 26 0 0 -65 23 0 3 -25 -26 0 0 -20c0,0 0,-8 7,-8l19 0z"/>
                           </svg>
                        </a>
                        <a href="https://twitter.com/NandishJewelers">
                           <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="30px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                              viewBox="0 0 1519 1534"
                              xmlns:xlink="http://www.w3.org/1999/xlink">
                              <path  d="M759 0c419,1 763,341 760,772 -2,423 -343,766 -769,762 -412,-5 -753,-342 -750,-772 2,-424 341,-760 759,-762zm0 1474c381,1 697,-309 701,-699 4,-401 -317,-712 -694,-715 -385,-3 -704,309 -706,701 -2,396 310,713 699,713z"/>
                              <path  d="M406 675c-20,-16 -37,-32 -50,-52 -40,-63 -45,-129 -13,-197 5,-11 8,-9 15,-1 58,68 129,119 212,153 48,20 99,34 151,38 10,1 23,8 30,0 4,-5 -2,-18 -3,-28 -2,-62 18,-116 65,-159 69,-63 170,-68 246,-14 6,4 13,7 17,13 9,11 19,12 32,8 32,-9 63,-20 92,-36 3,-2 6,-3 12,-5 -15,45 -42,77 -78,105 5,-1 10,-1 16,-2 5,-1 10,-2 16,-3 20,-5 39,-11 59,-18 3,-1 6,-6 9,-1 2,3 -2,5 -3,8 -23,30 -49,57 -79,80 -6,5 -9,10 -9,19 1,137 -40,260 -125,367 -69,88 -157,149 -264,181 -62,19 -126,27 -190,24 -95,-3 -184,-30 -266,-78 -3,-2 -7,-4 -13,-9 54,5 103,2 152,-12 48,-14 93,-36 135,-69 -22,-3 -41,-6 -60,-12 -56,-20 -94,-59 -117,-113 -4,-9 -5,-12 8,-11 23,4 46,3 72,-4 -16,-8 -31,-10 -45,-18 -66,-35 -102,-90 -108,-164 -1,-12 3,-12 11,-8 17,9 35,13 53,17 5,1 12,2 20,1z"/>
                           </svg>
                        </a>
                        <br>
                        <a href="https://www.linkedin.com/company/nandishjewellers">
                           <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="30px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                              viewBox="0 0 405 409"
                              xmlns:xlink="http://www.w3.org/1999/xlink">
                              <path  d="M0 201c2,-48 16,-89 45,-125 34,-42 78,-67 132,-74 62,-8 117,10 163,53 41,38 63,85 65,141 2,60 -18,112 -61,155 -33,32 -73,52 -119,56 -64,7 -120,-13 -166,-59 -34,-34 -53,-75 -58,-123 -1,-8 -1,-17 -1,-24zm202 192c102,0 186,-82 187,-186 1,-107 -83,-190 -184,-191 -103,-1 -188,82 -189,187 -1,105 83,190 186,190z"/>
                              <path  d="M214 185c1,1 1,0 2,-1 12,-18 30,-24 51,-22 25,4 42,20 47,47 1,5 2,11 2,17 0,29 0,57 0,86 0,2 -1,3 -4,3 -12,0 -25,0 -38,0 -3,0 -4,-1 -4,-4 0,-26 0,-52 0,-78 0,-5 0,-10 -2,-15 -2,-7 -7,-12 -15,-15 -19,-7 -39,5 -39,26 0,27 0,53 0,79 0,7 0,7 -7,7 -12,0 -23,0 -35,0 -3,0 -4,0 -4,-4 0,-46 0,-93 0,-140 0,-3 1,-3 4,-3 13,0 26,0 39,0 2,0 3,0 3,3 0,5 0,10 0,14z"/>
                              <path  d="M95 242c0,-23 0,-46 0,-69 0,-4 1,-5 4,-5 13,1 25,1 37,0 3,0 4,1 4,4 0,47 0,93 0,140 0,3 -1,3 -4,3 -12,0 -25,0 -38,0 -3,0 -3,-1 -3,-4 0,-23 0,-46 0,-69z"/>
                              <path  d="M93 116c0,-13 10,-23 24,-23 14,1 23,10 23,24 0,13 -10,23 -24,23 -13,0 -23,-10 -23,-24z"/>
                           </svg>
                        </a>
                        <a href="https://www.pinterest.com/nandishjewellers/">
                           <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="30px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                              viewBox="0 0 3968 4006"
                              xmlns:xlink="http://www.w3.org/1999/xlink">
                              <path  d="M1981 4006c-1101,0 -1987,-899 -1981,-2021 5,-1095 891,-1996 2006,-1985 1094,11 1974,913 1962,2025 -11,1090 -886,1979 -1987,1981zm4 -3849c-992,-4 -1818,805 -1829,1824 -12,1038 817,1859 1808,1868 1006,11 1842,-805 1848,-1830 4,-1034 -812,-1862 -1827,-1862z"/>
                              <path  d="M2080 593c327,2 595,126 788,394 144,202 190,431 163,677 -15,144 -41,285 -96,420 -82,199 -200,369 -398,468 -173,85 -351,110 -531,15 -49,-26 -90,-61 -123,-105 -6,-7 -10,-18 -21,-16 -12,2 -9,15 -11,23 -31,132 -61,264 -94,395 -42,163 -121,310 -213,449 -17,26 -34,51 -51,76 -7,10 -16,19 -30,15 -12,-4 -14,-15 -15,-26 -28,-221 -35,-442 19,-661 49,-198 87,-399 130,-599 15,-67 31,-134 47,-201 3,-12 4,-24 -1,-35 -52,-135 -61,-272 -21,-410 29,-99 77,-186 177,-232 134,-60 271,19 287,166 9,91 -8,179 -30,267 -32,126 -78,248 -100,377 -18,111 14,204 113,264 103,61 205,41 300,-22 98,-66 158,-162 202,-268 76,-186 107,-381 95,-582 -12,-213 -98,-386 -289,-496 -80,-45 -167,-66 -257,-74 -149,-13 -293,11 -426,84 -130,71 -227,173 -294,303 -83,161 -107,333 -80,511 10,64 34,123 75,172 37,44 42,89 27,141 -9,32 -16,64 -24,96 -12,46 -41,57 -85,36 -129,-60 -204,-166 -248,-295 -72,-214 -68,-429 7,-641 87,-245 245,-432 472,-557 166,-90 346,-132 536,-129z"/>
                           </svg>
                        </a>
                        <a href="https://nandishjewellers.tumblr.com/">
                           <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="30px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                              viewBox="0 0 637 642"
                              xmlns:xlink="http://www.w3.org/1999/xlink">
                              <path  d="M637 321c-6,129 -63,227 -178,287 -115,61 -262,38 -357,-52 -57,-53 -91,-119 -100,-197 -11,-98 17,-185 85,-258 51,-56 115,-89 190,-98 98,-12 184,15 256,82 58,53 90,120 101,197 0,5 1,10 1,15 0,8 0,16 0,24 1,0 1,0 2,0zm-320 295c160,1 292,-128 294,-292 1,-167 -132,-298 -290,-299 -161,-2 -295,129 -296,293 -1,166 130,298 292,298z"/>
                              <path  d="M432 442c2,2 1,4 1,6 0,17 0,35 0,52 0,4 -1,7 -5,9 -27,14 -56,20 -87,19 -34,-2 -63,-14 -83,-44 -9,-13 -10,-27 -10,-42 0,-50 -1,-100 -1,-150 0,-6 -2,-8 -8,-8 -9,1 -18,0 -28,1 -4,0 -5,-1 -5,-5 1,-17 1,-35 0,-52 0,-2 1,-4 3,-5 33,-13 53,-37 64,-70 4,-11 6,-22 7,-34 1,-4 3,-5 6,-5 15,0 29,0 43,0 5,0 5,3 5,6 0,31 0,62 0,93 0,5 1,6 6,6 25,0 50,0 75,0 5,0 7,1 7,6 -1,18 -1,36 0,54 0,4 -2,6 -6,6 -26,-1 -51,0 -76,-1 -5,0 -6,2 -6,7 0,39 0,77 0,116 0,6 1,11 1,17 0,25 21,36 39,36 19,1 36,-4 53,-15 1,-1 3,-2 4,-3 1,0 1,0 1,0z"/>
                           </svg>
                        </a>
                        <a href="https://www.youtube.com/channel/UCvfGeR0YCu38rJmv4ZF1kXg">
                           <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" width="30px" height="30px" version="1.1" style="shape-rendering:geometricPrecision; text-rendering:geometricPrecision; image-rendering:optimizeQuality; fill-rule:evenodd; clip-rule:evenodd"
                              viewBox="0 0 875 883"
                              xmlns:xlink="http://www.w3.org/1999/xlink">
                              <path  d="M438 0c242,0 438,198 437,445 -1,242 -197,441 -443,438 -240,-3 -434,-201 -432,-446 2,-241 196,-437 438,-437zm0 35c-219,-1 -401,177 -403,402 -3,229 180,410 399,412 221,2 405,-178 406,-403 2,-229 -178,-411 -402,-411z"/>
                              <path  d="M422 267c71,0 129,1 188,4 14,1 29,1 43,6 29,9 42,32 49,59 6,28 7,56 7,83 2,50 2,99 -4,148 -2,16 -6,32 -14,46 -11,21 -30,31 -52,34 -24,4 -48,4 -72,5 -98,4 -197,3 -295,-1 -16,-1 -33,-2 -49,-5 -24,-6 -42,-19 -51,-43 -10,-28 -11,-56 -13,-84 -2,-55 -2,-109 4,-163 2,-16 6,-31 13,-45 12,-26 35,-36 62,-38 65,-5 131,-6 184,-6zm-46 273c54,-29 107,-58 161,-88 -14,-8 -26,-15 -39,-21 -38,-21 -76,-42 -114,-63 -3,-1 -8,-6 -8,3 0,56 0,112 0,169z"/>
                           </svg>
                        </a>
                     </div>
                  </div>
               </div>
            </div>
         </aside>
      </header>
      <main>