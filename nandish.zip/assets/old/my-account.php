<?php
	include('include/header.php');
    if (!isset($_SESSION['id'])) {
        echo '<script>alert("Please login first.");window.open("login-register.php","_self");</script>';
    }

    if (isset($_POST['submit']))
    {
        $u_f_name = $_POST['fname'];
        $u_l_name = $_POST['lname'];
        $u_m_name = $_POST['mname'];
        $mobile = $_POST['mobile'];
        $email = $_POST['email'];
        $address = "NA";
        $password = $_POST['password'];
        if(empty($password))
        {
            $sql_up = "UPDATE `user` SET `u_f_name` = '$u_f_name', `u_m_name` = '$u_m_name', `u_l_name` = '$u_l_name', `u_mobile` = '$mobile', `u_email` = '$email', `u_address` = '$address' where `u_id` = '$id'";
        }
        else
        {
            $pass = md5($password);
            $sql_up = "UPDATE `user` SET `u_f_name` = '$u_f_name', `u_m_name` = '$u_m_name', `u_l_name` = '$u_l_name', `u_mobile` = '$mobile', `u_password` = '$pass', `u_email` = '$email', `u_address` = '$address' where `u_id` = '$id'";
        }
        
        $run_up = mysqli_query($connect,$sql_up);
        if($run_up == true)
        {
            echo "<script>alert('Update successfully');window.open('my-account.php','_self');</script>";
        }
        else
        {
           echo "<script>alert('Update Are Not successfully');window.open('my-account.php','_self');</script>";
        }
    }
?>

<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url() ?>"><i class="fa fa-home"></i></a></li>
                            <li class="breadcrumb-item active" aria-current="page">my-account</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="my-account-wrapper section-padding">
    <div class="container">
        <div class="section-bg-color">
            <div class="row">
                <div class="col-lg-12">
                    <!-- My Account Page Start -->
                    <div class="myaccount-page-wrapper">
                        <!-- My Account Tab Menu Start -->
                        <div class="row">
                            <div class="col-lg-3 col-md-4">
                                <div class="myaccount-tab-menu nav" role="tablist">
                                    <a href="#dashboad" class="active" data-toggle="tab"><i
                                        class="fa fa-dashboard"></i>
                                    Dashboard</a>
                                    <a href="#orders" data-toggle="tab"><i class="fa fa-cart-arrow-down"></i>Complete
                                    Orders</a>
                                    <!-- <a href="#address-edit" data-toggle="tab"><i class="fa fa-map-marker"></i>
                                    address</a> -->
                                    <a href="#account-info" data-toggle="tab"><i class="fa fa-user"></i> Account
                                    Details</a>
                                    <a href="<?= base_url() ?>logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                </div>
                            </div>
                            <!-- My Account Tab Menu End -->
                            <!-- My Account Tab Content Start -->
                            <div class="col-lg-9 col-md-8">
                                <div class="tab-content" id="myaccountContent">
                                    <!-- Single Tab Content Start -->
                                    <div class="tab-pane fade show active" id="dashboad" role="tabpanel">
                                        <div class="myaccount-content">
                                            <h5>Dashboard</h5>
                                            <div class="myaccount-table table-responsive text-center">
                                                <table class="table table-bordered">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>Order</th>
                                                            <th>Date / Time</th>
                                                            <th>Status</th>
                                                            <th>Total</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $sql = "SELECT * FROM orders where o_u_id = '$id' AND o_status IN (0,1)";
                                                        $run = mysqli_query($connect,$sql);
                                                        $i = 1;
                                                        if (mysqli_num_rows($run) > 0):
                                                            while ($data = mysqli_fetch_assoc($run)):
                                                        ?>
                                                        <tr>
                                                            <td><?= $i++; ?></td>
                                                            <td><?= $data['o_date'].' / '.$data['o_time']; ?></td>
                                                            <td>
                                                                <?php
                                                                if($data['o_status'] == 0)
                                                                {
                                                                echo "Pending";
                                                                }
                                                                elseif($data['o_status'] == 1)
                                                                {
                                                                echo "Confirm";
                                                                }
                                                                ?>
                                                            </td>
                                                            <td><i class="fa fa-inr" aria-hidden="true"></i><?= $data['o_total'] ?></td>
                                                            <td>
                                                                <a href="<?= base_url() ?>invoice.php?o_id=<?= $data['o_id']; ?>" class="btn btn-sqr">View</a>
                                                                <?php
                                                                if($data['o_status'] == 0)
                                                                {
                                                                ?>
                                                                <a href="<?= base_url() ?>cancel.php?o_id=<?= $data['o_id']; ?>" class="btn btn-sqr">Cancel</a>
                                                                <?php } ?>
                                                            </td>
                                                        </tr>
                                                        <?php endwhile ?>
                                                        <?php else: ?>
                                                            <tr>
                                                                <td colspan="5">No orders available.</td>
                                                            </tr>
                                                        <?php endif ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Single Tab Content End -->
                                    <!-- Single Tab Content Start -->
                                    <div class="tab-pane fade" id="orders" role="tabpanel">
                                        <div class="myaccount-content">
                                            <h5>Orders</h5>
                                            <div class="myaccount-table table-responsive text-center">
                                                <table class="table table-bordered">
                                                    <thead class="thead-light">
                                                        <tr>
                                                            <th>Order</th>
                                                            <th>Date / Time</th>
                                                            <th>Status</th>
                                                            <th>Total</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        $sql = "SELECT * FROM orders where o_u_id = '$id' AND o_status = 2";
                                                        $run = mysqli_query($connect,$sql);
                                                        $i = 1;
                                                        
                                                        if (mysqli_num_rows($run) > 0):
                                                            while ($data = mysqli_fetch_assoc($run)):
                                                        ?>
                                                        <tr>
                                                            <td><?= $i++; ?></td>
                                                            <td><?= $data['o_date'].' / '.$data['o_time']; ?></td>
                                                            <td>Completed</td>
                                                            <td><i class="fa fa-inr" aria-hidden="true"></i><?= $data['o_total'] ?></td>
                                                            <td><a href="<?= base_url() ?>invoice.php?o_id=<?= $data['o_id']; ?>" class="btn btn-sqr">View</a>
                                                            <?php
                                                            if($data['o_id'] == 0)
                                                            {
                                                            ?>
                                                            <a href="<?= base_url() ?>return.php?o_id=<?= $data['o_id']; ?>" class="btn btn-sqr">Return</a>
                                                            <?php } ?>
                                                        </td>
                                                    </tr>
                                                    <?php endwhile ?>
                                                    <?php else: ?>
                                                        <tr>
                                                            <td colspan="5">No orders available.</td>
                                                        </tr>
                                                    <?php endif ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- Single Tab Content End -->
                                <!-- Single Tab Content Start -->
                                <!-- <div class="tab-pane fade" id="address-edit" role="tabpanel">
                                    <div class="myaccount-content">
                                        <h5>Billing Address</h5>
                                        <address>
                                            <p><strong>Erik Jhonson</strong></p>
                                            <span><strong>City:</strong> Seattle</span>,
                                            <br>
                                            <span><strong>State:</strong> Washington(WA)</span>,
                                            <br>
                                            <span><strong>ZIP:</strong> 98101</span>,
                                            <br>
                                            <span><strong>Country:</strong> USA</span>
                                        </address>
                                        <a href="#" class="btn btn-sqr"><i class="fa fa-edit"></i>
                                        Edit Address</a>
                                    </div>
                                </div> -->
                                <!-- Single Tab Content End -->
                                <?php
                                $sql_us = "SELECT * FROM user where u_id = '$id'";
                                $run_us=mysqli_query($connect,$sql_us);
                                $data_us = mysqli_fetch_assoc($run_us);
                                ?>
                                <!-- Single Tab Content Start -->
                                <div class="tab-pane fade" id="account-info" role="tabpanel">
                                    <div class="myaccount-content">
                                        <h5>Account Details</h5>
                                        <div class="account-details-form">
                                            <form method="post">
                                                <div class="row ">
                                                    <div class="col-12 single-input-item">
                                                        <input type="text" placeholder="First Name" required name="fname" value="<?= $data_us['u_f_name'] ?>" />
                                                    </div>
                                                </div>
                                                <div class="row ">
                                                    <div class="col-12 single-input-item">
                                                        <input type="text" placeholder="Middle Name" required name="mname" value="<?= $data_us['u_m_name'] ?>" />
                                                    </div>
                                                </div>
                                                <div class="row ">
                                                    <div class="col-12 single-input-item">
                                                        <input type="text" placeholder="Last Name" required name="lname" value="<?= $data_us['u_l_name'] ?>" />
                                                    </div>
                                                </div>
                                                <div class="row ">
                                                    <div class="col-12 single-input-item">
                                                        <input type="text" placeholder="Mobile Number" required name="mobile" value="<?= $data_us['u_mobile'] ?>" maxlength="10" />
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-12 single-input-item">
                                                        <input type="email" placeholder="Enter your Email" required name="email" value="<?= $data_us['u_email'] ?>" />
                                                    </div>
                                                </div>
                                                <!-- <div class="row ">
                                                    <div class="col-12 single-input-item">
                                                        <input type="text" placeholder="Address" required name="address" value="<?= $data_us['u_address'] ?>" />
                                                    </div>
                                                </div> -->
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="single-input-item">
                                                            <input type="password" placeholder="Enter your Password" name="password" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="single-input-item">
                                                    <div class="login-reg-form-meta">
                                                        <div class="remember-meta">
                                                            <div class="custom-control custom-checkbox">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="single-input-item">
                                                    <button class="btn btn-sqr" name="submit">Save The Changes</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    </div> <!-- Single Tab Content End -->
                                </div>
                                </div> <!-- My Account Tab Content End -->
                            </div>
                            </div> <!-- My Account Page End -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include('include/footer.php') ?>