<?php

if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ):
	session_start();
	if (!isset($_SESSION['id'])) {
		$return = ['error' => true, 'message' => "Login first"];
		echo json_encode($return); die();
	}
    include("admin/layout/connect.php");
    $post = (object) $_POST;
    $sql = "DELETE FROM cart WHERE ca_id = '$post->cart_id'";
    if (mysqli_query($connect, $sql))
        $return = ['error' => false, 'message' => "Jewellery removed from cart."];
    else
        $return = ['error' => true, 'message' => "Jewellery not removed from cart."];

    echo json_encode($return); die();
else:
    echo '<script>window.open("index.php","_self");</script>';
endif;