<?php
	include("admin/layout/connect.php");
	session_start();
	if (!isset($_SESSION['id'])) {
	    echo '<script>alert("Please login first.");window.open("login-register.php","_self");</script>';
	}
	$o_id = $_GET['o_id'];

	$sql = "SELECT * FROM orders where o_id = '$o_id' AND o_return = 0";
	if(mysqli_query($connect,$sql))
	{
		$sql_up = "UPDATE orders SET o_return = 1 where o_id = '$o_id'";
		$run_up = mysqli_query($connect,$sql_up);
		echo "<script>alert('Return Order Successfully');window.open('my-account.php','_self');</script>";
	}
	else
	{
		echo "<script>alert('Return Order Not successfully');window.open('my-account.php','_self');</script>";
	}
?>