<?php
	include("admin/layout/connect.php");
	session_start();
	if (!isset($_SESSION['id'])) {
	    echo '<script>alert("Please login first.");window.open("login-register.php","_self");</script>';
	}
	
	$o_id = $_GET['o_id'];

	$sql = "SELECT * FROM orders where o_id = '$o_id' AND o_status = 0";
	$run = mysqli_query($connect,$sql);

	if(0 < mysqli_num_rows($run))
	{
		$sql1 = "UPDATE orders SET o_status = 3 where o_id = '$o_id'";
		$run1 = mysqli_query($connect,$sql1);

		echo '<script>alert("Your Order Cancel Successfully");window.open("my-account.php","_self");</script>';
	}
	else
	{
		echo "<script>alert('Order Cancel Not Successfully');window.open('my-account.php','_self');</script>";
		
	}