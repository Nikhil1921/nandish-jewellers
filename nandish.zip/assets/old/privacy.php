<?php include('include/header.php'); 
$sql = "SELECT details FROM page WHERE p_page = 'privacy'";
$run = mysqli_query($connect, $sql);
$data = (object) mysqli_fetch_assoc($run);
?>
<section class="privacy">
	<div class="container">
		<h2 class="text-center">Privacy Policy</h2>
		<?= $data->details ?>
	</div>
</section>
<?php include('include/footer.php') ?>