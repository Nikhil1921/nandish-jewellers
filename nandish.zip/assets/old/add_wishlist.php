<?php
if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ):
	include("admin/layout/connect.php");
	session_start();
	if (!isset($_SESSION['id'])) {
		$return = ['error' => true, 'message' => "Login first"];
		echo json_encode($return); die();
	}
	$u_id = $_SESSION['id'];
	$p_id = $_POST['p_id'];
	$sql = "SELECT * FROM wish where w_u_id = '$u_id' AND w_p_id = '$p_id'";
	$run = mysqli_query($connect,$sql);

	if(0 < mysqli_num_rows($run))
	{
		$return = ['error' => false, 'message' => "This Jewellery Is Alredy In Wishlist."];
	}
	else
	{
		$cart = "INSERT INTO wish (w_u_id, w_p_id) VALUES ('$u_id','$p_id')";
		if(mysqli_query($connect, $cart))
			$return = ['error' => false, 'message' => "Add Wish List Successfully."];
		else
			$return = ['error' => false, 'message' => "Add Wish List Not successfully."];
	}
	echo json_encode($return); die();
else:
	echo '<script>window.open("index.php","_self");</script>';
endif;